package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class AdtionalDetalsInterEntity extends GenericEntity {

	public AdtionalDetalsInterEntity() {
		super("AdtionalDetalsInterEntity");
		// TODO Auto-generated constructor stub
	}

}
