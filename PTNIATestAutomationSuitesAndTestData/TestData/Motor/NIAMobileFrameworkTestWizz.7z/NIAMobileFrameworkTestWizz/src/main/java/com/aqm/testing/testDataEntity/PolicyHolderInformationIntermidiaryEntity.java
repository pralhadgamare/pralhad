package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class PolicyHolderInformationIntermidiaryEntity extends GenericEntity{

	public PolicyHolderInformationIntermidiaryEntity() {
		super("PolicyHolderInformationIntermidiaryEntity");
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	

}
