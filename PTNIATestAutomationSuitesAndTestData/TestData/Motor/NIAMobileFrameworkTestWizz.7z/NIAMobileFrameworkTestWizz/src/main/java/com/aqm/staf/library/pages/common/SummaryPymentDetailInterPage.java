package com.aqm.staf.library.pages.common;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import com.aqm.framework.constant.AssertionType;
import com.aqm.framework.constant.WaitType;
import com.aqm.framework.core.CustomAssert;
import com.aqm.framework.core.MobileScreen;
import com.aqm.framework.core.MobileScreenElement;
import com.aqm.testing.testDataEntity.SummaryIntermidiarEntity;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class SummaryPymentDetailInterPage extends MobileScreen  {

	MobileScreenElement Policyperiod;
	MobileScreenElement quoteNoLabel;
	MobileScreenElement GrosspremiumLabel;
	MobileScreenElement GoodsServiceTaxLabel;
	MobileScreenElement NetpremiumLabel;
	MobileScreenElement ApproveAndPayButton;
	MobileScreenElement AlertConfermButton;
	MobileScreenElement APProveproposal;
	MobileScreenElement OkAlerTButton;
	MobileScreenElement saveAndCalculatePremiumButton;
	MobileScreenElement ApproveAndPayHealthButton;
	MobileScreenElement okButton;
	MobileScreenElement browseButton;
	MobileScreenElement choosePhotoFromGalleryButton;
	MobileScreenElement photo;
	MobileScreenElement uploadButton;

	public SummaryPymentDetailInterPage(AppiumDriver driver, String screenName) {

		super((AndroidDriver) driver,screenName);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			Policyperiod=new MobileScreenElement(By.xpath("//android.view.View[@text='Policy Period']/following::android.view.View"), "policy period ", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			quoteNoLabel=new MobileScreenElement(By.xpath("//android.view.View[(@text='Quote No.')]//following::android.view.View"), "Quote No.", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			GrosspremiumLabel=new MobileScreenElement(By.xpath("//android.view.View[@text='Gross Premium' and @index='5')]//following::android.view.View"), "Gross Premium", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			GoodsServiceTaxLabel=new MobileScreenElement(By.xpath("//android.view.View[@text='Goods & Services Tax (GST)' and @index='9')]//following::android.view.View"), "Goods & Services Tax (GST)", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			NetpremiumLabel=new MobileScreenElement(By.xpath("//android.view.View[@text='Net premium' and @index='13')]//following::android.view.View"), "Net premium", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			ApproveAndPayButton=new MobileScreenElement(By.xpath("//android.widget.Button[@text='Approve & Pay']"), "Approve And Pay", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			AlertConfermButton=new MobileScreenElement(By.xpath("//android.widget.Button[@text='Confirm']"), "Confirm", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			APProveproposal=new MobileScreenElement(By.xpath("//android.widget.TextView[@resource-id='android:id/message')]"), "Quote No.", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			OkAlerTButton=new MobileScreenElement(By.xpath("//android.widget.Button[@text='OK']"), "Ok", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			saveAndCalculatePremiumButton=new MobileScreenElement(By.xpath("//android.widget.Button[@text='Save & Calculate Premium']"), "Save & Re-Calculate Premium", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			ApproveAndPayHealthButton=new MobileScreenElement(By.xpath("//android.widget.Button[@text='Approve & Pay']"), "Approve And Pay", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			okButton=new MobileScreenElement(By.xpath("//android.widget.Button[@text='OK']"), "OK", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			browseButton=new MobileScreenElement(By.xpath("//android.view.View[@text='BROWSE']"), "BROWSE", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			choosePhotoFromGalleryButton=new MobileScreenElement(By.xpath("//android.view.View[@text='Choose photo from Gallery']"), "Choose photo from Gallery", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			photo=new MobileScreenElement(By.xpath("//android.widget.TextView[@resource-id='android:id/title']"), "Photo", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			uploadButton=new MobileScreenElement(By.xpath("//android.widget.Button[@text='Upload']"), "Upload", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			
	}
	public void fillSummaryPageDetails(SummaryIntermidiarEntity summaryIntermidiarEntity,CustomAssert assertReference ) throws InterruptedException{

		if(summaryIntermidiarEntity.getAction().equalsIgnoreCase("verify")){

			if(summaryIntermidiarEntity.getBooleanValueForField("ConfigQuoteNo")){
				assertReference.assertEquals(summaryIntermidiarEntity.getStringValueForField("QuoteNo"),fetchValueFromFields(quoteNoLabel),AssertionType.WARNING);
			}
			if(summaryIntermidiarEntity.getBooleanValueForField("ConfigGrossPremium")){
				assertReference.assertEquals(summaryIntermidiarEntity.getStringValueForField("GrossPremium"),fetchValueFromFields(quoteNoLabel),AssertionType.WARNING);
			}
			if(summaryIntermidiarEntity.getBooleanValueForField("ConfigGoodsAndServicesTax")){
				assertReference.assertEquals(summaryIntermidiarEntity.getStringValueForField("GoodsAndServicesTax"),fetchValueFromFields(GrosspremiumLabel),AssertionType.WARNING);
			}
			if(summaryIntermidiarEntity.getBooleanValueForField("ConfigNetPremiumLabel")){
				assertReference.assertEquals(summaryIntermidiarEntity.getStringValueForField("NetPremiumLabel"),fetchValueFromFields(GoodsServiceTaxLabel),AssertionType.WARNING);
			}
			if(summaryIntermidiarEntity.getBooleanValueForField("ConfigProductName")){
				assertReference.assertEquals(summaryIntermidiarEntity.getStringValueForField("ProductName"),fetchValueFromFields(NetpremiumLabel),AssertionType.WARNING);
			}

		}
	}
	
	public void fetchQuoteNumber(SummaryIntermidiarEntity summaryIntermidiarEntity) throws InterruptedException {
		if(summaryIntermidiarEntity.getBooleanValueForField("ConfigQuoteNoHome")){
			summaryIntermidiarEntity.setStringValueForField("QuoteNo", fetchValueFromFields(quoteNoLabel));
		}
	}
	public void fetchPolicyPeriod(SummaryIntermidiarEntity summaryIntermidiarEntity) throws InterruptedException {
		if(summaryIntermidiarEntity.getBooleanValueForField("ConfigPolicyperiod")){
			summaryIntermidiarEntity.setStringValueForField("policyperiod", fetchValueFromFields(Policyperiod));
		}
	}
	public void fetchalertofApproveproposal(SummaryIntermidiarEntity summaryIntermidiarEntity) throws InterruptedException {
		if(summaryIntermidiarEntity.getBooleanValueForField("ConfigApproveproposal")){
			summaryIntermidiarEntity.setStringValueForField("Approveproposal", fetchValueFromFields(APProveproposal));
			click(OkAlerTButton);

		}
	}

	public void clickOnApproveAndPay(SummaryIntermidiarEntity summaryIntermidiarEntity) {
		if(summaryIntermidiarEntity.getBooleanValueForField("ConfigApprove")){
			click(ApproveAndPayButton);
			
			click(AlertConfermButton);
			click(OkAlerTButton);
		}
	}
	public void browseCancerGuardHealthDocument(SummaryIntermidiarEntity summaryIntermidiarEntity) throws InterruptedException {
		if(summaryIntermidiarEntity.getBooleanValueForField("ConfigBrowseDocumentHealth")){
			click(browseButton);
			click(choosePhotoFromGalleryButton);
			Thread.sleep(2000);
			click(photo);
			Thread.sleep(2000);
			click(uploadButton);
			Thread.sleep(2000);
			click(okButton);
		}
	}
	
	public void clickOnApproveAndPayHealth(SummaryIntermidiarEntity summaryIntermidiarEntity) {
		if(summaryIntermidiarEntity.getBooleanValueForField("ConfigApproveHealth")){
			scrollDown();
			click(ApproveAndPayHealthButton);
			click(AlertConfermButton);
			try {
			click(okButton);
			}
			catch(Exception e) {
				
			}
		}
	}
	

	public void clickOnSaveAndReCalculatePremium(SummaryIntermidiarEntity summaryIntermidiarEntity) {
		if(summaryIntermidiarEntity.getBooleanValueForField("ConfigSaveAndReCalclatePremium")){
			click(saveAndCalculatePremiumButton);
			//click(AlertConfermButton);
		}

	}


	public void fillAndSubmitPremiumSummaryPageDetails(SummaryIntermidiarEntity summaryIntermidiarEntity,CustomAssert assertReference,String stepGroup) throws InterruptedException{
		if(isConfigTrue(summaryIntermidiarEntity.getConfigExecute())) {
			
			fetchQuoteNumber(summaryIntermidiarEntity);
			fetchPolicyPeriod(summaryIntermidiarEntity);
			scrollToElementForward();
			fillSummaryPageDetails(summaryIntermidiarEntity, assertReference);
			clickOnSaveAndReCalculatePremium(summaryIntermidiarEntity);
			clickOnApproveAndPay(summaryIntermidiarEntity);
			clickOnApproveAndPayHealth(summaryIntermidiarEntity);
			browseCancerGuardHealthDocument(summaryIntermidiarEntity);
			fetchalertofApproveproposal(summaryIntermidiarEntity);
			
			
		}
	}
}