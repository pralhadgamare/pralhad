package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class PremiumSummaryEntity extends GenericEntity{

	public PremiumSummaryEntity() {
		super("PremiumSummaryEntity");
		// TODO Auto-generated constructor stub
	}

}
