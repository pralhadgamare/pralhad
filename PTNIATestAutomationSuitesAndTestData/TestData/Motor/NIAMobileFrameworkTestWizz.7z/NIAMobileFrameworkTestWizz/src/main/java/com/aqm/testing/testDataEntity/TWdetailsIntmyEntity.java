package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class TWdetailsIntmyEntity extends GenericEntity {

	public TWdetailsIntmyEntity() {
		super("TWdetailsIntmyEntity");
		// TODO Auto-generated constructor stub
	}

}
