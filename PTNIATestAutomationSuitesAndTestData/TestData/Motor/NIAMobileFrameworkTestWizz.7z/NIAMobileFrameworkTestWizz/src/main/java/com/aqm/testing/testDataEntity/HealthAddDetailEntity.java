package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class HealthAddDetailEntity extends GenericEntity {

	public HealthAddDetailEntity() {
		super("HealthAddDetailEntity");
		// TODO Auto-generated constructor stub
	}

}
