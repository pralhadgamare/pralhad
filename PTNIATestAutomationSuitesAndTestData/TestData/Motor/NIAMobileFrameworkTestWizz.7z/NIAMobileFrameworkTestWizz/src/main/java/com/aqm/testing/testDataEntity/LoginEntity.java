package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;
/********************************CorporationBAnk************************/

public class LoginEntity extends GenericEntity {

	public LoginEntity() {
		super("LoginEntity");
		// TODO Auto-generated constructor stub
	}

}