package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class VehicleDetailsIntmyEntity extends GenericEntity {

	public VehicleDetailsIntmyEntity() {
		super("VehicleDetailsIntmyEntity");
		// TODO Auto-generated constructor stub
	}

}
