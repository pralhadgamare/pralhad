package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class PremiumCalEntity extends GenericEntity {

	public PremiumCalEntity() {
		super("PremiumCalEntity");
		// TODO Auto-generated constructor stub
	}

}
