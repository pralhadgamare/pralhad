package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class PrivateCarEntity extends GenericEntity{

	public PrivateCarEntity() {
		super("PrivateCarEntity");
		// TODO Auto-generated constructor stub
	}

}
