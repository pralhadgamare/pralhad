package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class CollectionIntemidiaryEntity extends GenericEntity {
	public CollectionIntemidiaryEntity() {
		super("CollectionIntemidiaryEntity");
		// TODO Auto-generated constructor stub
	}

}



