package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class DetailedTravelEntity extends GenericEntity{
	public DetailedTravelEntity() {
		super("DetailedTravelEntity");
		// TODO Auto-generated constructor stub
	}
}
