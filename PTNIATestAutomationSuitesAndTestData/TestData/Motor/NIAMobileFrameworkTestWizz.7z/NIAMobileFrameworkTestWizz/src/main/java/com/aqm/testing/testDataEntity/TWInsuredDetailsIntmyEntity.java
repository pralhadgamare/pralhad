package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class TWInsuredDetailsIntmyEntity extends GenericEntity {

	public TWInsuredDetailsIntmyEntity() {
		super("TWInsuredDetailsIntmyEntity");
		// TODO Auto-generated constructor stub
	}

}
