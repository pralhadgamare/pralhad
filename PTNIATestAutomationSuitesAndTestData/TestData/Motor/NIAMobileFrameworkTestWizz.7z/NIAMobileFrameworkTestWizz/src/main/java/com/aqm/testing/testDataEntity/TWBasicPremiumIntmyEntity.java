package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class TWBasicPremiumIntmyEntity extends GenericEntity {

	public TWBasicPremiumIntmyEntity() {
		super("TWBasicPremiumIntmyEntity");
		// TODO Auto-generated constructor stub
	}

}
