package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class PremiumCalculateEntity  extends GenericEntity{
	public PremiumCalculateEntity() {
		super("PremiumCalculateEntity");
		// TODO Auto-generated constructor stub
	}

}
