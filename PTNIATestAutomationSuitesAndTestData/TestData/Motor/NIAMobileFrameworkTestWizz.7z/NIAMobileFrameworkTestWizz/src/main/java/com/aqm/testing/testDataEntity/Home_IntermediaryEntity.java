package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class Home_IntermediaryEntity extends GenericEntity{
	public Home_IntermediaryEntity() {
		super("Home_IntermediaryEntity");
		// TODO Auto-generated constructor stub
	}
}
