package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class TopUpMediEntity extends GenericEntity {

	public TopUpMediEntity() {
		super("TopUpMediEntity");
		// TODO Auto-generated constructor stub
	}

}
