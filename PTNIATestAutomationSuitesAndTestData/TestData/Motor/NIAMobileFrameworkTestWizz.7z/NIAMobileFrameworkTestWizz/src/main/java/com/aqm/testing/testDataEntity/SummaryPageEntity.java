package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class SummaryPageEntity extends GenericEntity {

	public SummaryPageEntity() {
		super("SummaryPageEntity");
		// TODO Auto-generated constructor stub
	}

}
