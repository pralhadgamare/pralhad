package com.aqm.staf.library;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class GenericTable extends BasePage{
	String tableColumnHeaderRow;
	HashMap<Integer, String> columnHeaderIndex=new HashMap<Integer, String>();
	List<HashMap<Integer,String>> tableRows;
	String tablePath;
	String tableColumnHeaderData;
	public HashMap<Integer, String> visibleColumnIndexNames = new HashMap<Integer, String>();
	public HashMap<String, Integer> visibleColumnNamesIndex = new HashMap<String, Integer>();
	public HashMap<Integer, String> columnIndexNames = new HashMap<Integer, String>();
	private HashMap<String, Integer> columnNamesIndex = new HashMap<String, Integer>();
	public ArrayList<HashMap<String, String>> allRows;
	private ArrayList<Integer> rowVisibleHiddenMapper;

	public GenericTable(String tablePath, AndroidDriver driver) {
		super(driver, tablePath);
		this.driver=driver;
		this.tablePath=tablePath;
		this.tableColumnHeaderRow=tablePath+"//tr[1]";
		this.tableColumnHeaderData=tableColumnHeaderRow+"//td";
		
		getTableHeaders();
	}
	public void getTableHeaders(){
		
		int columnIndex=0;
		int visibleColumnIndex=0;
		String columnName;
		WebElement ColumnHeader=driver.findElement(By.xpath(tableColumnHeaderRow));
		List<WebElement> columnHead=ColumnHeader.findElements(By.xpath(tableColumnHeaderData));
		System.out.println(columnHead.size());
		for(WebElement column:columnHead){
			columnIndex++;
			if(columnIndex==1 && column.getText().equalsIgnoreCase("")){
				columnName="SelectRow";
			}
			else{
				WebElement columnHeadElement;
				columnHeadElement=column.findElement(By.xpath(".//b"));
				columnName=columnHeadElement.getText();
			}
			visibleColumnIndex++;
			columnHeaderIndex.put(columnIndex, columnName);
			visibleColumnIndexNames.put(visibleColumnIndex, columnName);
			visibleColumnNamesIndex.put(columnName, visibleColumnIndex);
			columnNamesIndex.put(columnName, columnIndex);
		}
	}
public void getTableRows(){


	rowVisibleHiddenMapper = new ArrayList<Integer>();

		allRows = new ArrayList<HashMap<String, String>>();
		ArrayList<Integer> columnIndexes = new ArrayList<Integer>(columnHeaderIndex.keySet());
	
}
}