package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class PersonalAccidentDetEntity extends GenericEntity {
	public PersonalAccidentDetEntity() {
		super("PersonalAccidentDetEntity");
}
}
