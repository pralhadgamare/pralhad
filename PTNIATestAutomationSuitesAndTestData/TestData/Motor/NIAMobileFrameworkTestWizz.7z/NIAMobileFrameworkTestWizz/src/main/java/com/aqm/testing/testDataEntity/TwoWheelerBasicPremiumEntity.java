package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class TwoWheelerBasicPremiumEntity extends GenericEntity {

	public TwoWheelerBasicPremiumEntity() {
		super("TwoWheelerBasicPremiumEntity");
		// TODO Auto-generated constructor stub
	}

}
