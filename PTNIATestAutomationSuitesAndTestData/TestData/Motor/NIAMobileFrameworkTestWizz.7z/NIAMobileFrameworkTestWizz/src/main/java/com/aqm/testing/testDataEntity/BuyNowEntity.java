package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class BuyNowEntity extends GenericEntity {

	public BuyNowEntity() {
		super("BuyNowEntity");
		// TODO Auto-generated constructor stub
	}

}
