package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class AdditionalDetailsMotorEntity extends GenericEntity {

	public AdditionalDetailsMotorEntity() {
		super("AdditionalDetailsMotorEntity");
		// TODO Auto-generated constructor stub
	}

}
