package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class QuickRenewPolicyEntity extends GenericEntity{

	public QuickRenewPolicyEntity() {
		super("QuickRenewPolicyEntity");
		// TODO Auto-generated constructor stub
	}

}
