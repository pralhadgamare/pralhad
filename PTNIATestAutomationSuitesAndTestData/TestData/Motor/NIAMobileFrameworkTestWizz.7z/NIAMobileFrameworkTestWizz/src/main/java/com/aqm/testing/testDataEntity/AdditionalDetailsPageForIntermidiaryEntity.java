package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class AdditionalDetailsPageForIntermidiaryEntity extends GenericEntity {

	public AdditionalDetailsPageForIntermidiaryEntity() {
		super("AdditionalDetailsPageForIntermidiaryEntity");
		// TODO Auto-generated constructor stub
	}

}
