package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class TwoWheelerBuyInsuranceEntity extends GenericEntity{

	public TwoWheelerBuyInsuranceEntity() {
		super("TwoWheelerBuyInsuranceEntity");
		// TODO Auto-generated constructor stub
	}

}
