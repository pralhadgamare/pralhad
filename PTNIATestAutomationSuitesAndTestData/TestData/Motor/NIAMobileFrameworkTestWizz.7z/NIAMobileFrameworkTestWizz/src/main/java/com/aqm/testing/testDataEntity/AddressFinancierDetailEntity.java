package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class AddressFinancierDetailEntity extends GenericEntity{

	public AddressFinancierDetailEntity() {
		super("AddressFinancierDetailEntity");
		// TODO Auto-generated constructor stub
	}

}
