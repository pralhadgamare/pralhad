package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class HomeIntermediaryEntity extends GenericEntity{
	public HomeIntermediaryEntity() {
		super("HomeIntermediaryEntity");
		// TODO Auto-generated constructor stub
	}
}
