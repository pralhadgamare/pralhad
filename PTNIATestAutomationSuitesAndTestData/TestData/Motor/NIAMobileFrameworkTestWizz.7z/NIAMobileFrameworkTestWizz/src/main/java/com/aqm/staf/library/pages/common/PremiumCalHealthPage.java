package com.aqm.staf.library.pages.common;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import com.aqm.framework.constant.WaitType;
import com.aqm.framework.core.CustomAssert;
import com.aqm.framework.core.MobileScreen;
import com.aqm.framework.core.MobileScreenElement;
import com.aqm.testing.testDataEntity.PremiumCalEntity;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.offset.PointOption;

public class PremiumCalHealthPage extends MobileScreen {
	MobileScreenElement floaterCoverRadioButton;
	MobileScreenElement thresholdLimitDropDown;
	MobileScreenElement sumInsuredDropDown;
	MobileScreenElement proposer1DOBTextField;
	MobileScreenElement individualCoverRadioButton;
	MobileScreenElement thresholdRadioButton1;
	MobileScreenElement SIRadioButton1;
	MobileScreenElement termsAndConditionsCheckBox;
	MobileScreenElement calculatePremiumButton;
	MobileScreenElement addSpouseButton;
	MobileScreenElement addChildButton;
	MobileScreenElement planARadioButton1;
	MobileScreenElement planADropDown;
	MobileScreenElement spouse1DOBTextField;
	MobileScreenElement continueButton;
	MobileScreenElement yearDropdown;
	MobileScreenElement yearOption;
	MobileScreenElement dateOption;
	MobileScreenElement sumInsuredDropDown2;
	MobileScreenElement SIRadioButton2;
	MobileScreenElement termsAndConditionsCheckBox2;
	MobileScreenElement XProposer;
	MobileScreenElement okbutton;
	MobileScreenElement thresholdRadioButton2;
	MobileScreenElement proposerAdd;
	MobileScreenElement sumInsuredCanGuardDropDown;
	MobileScreenElement genderMaleCGRadioButton;
	MobileScreenElement smokerRadioButton;
	MobileScreenElement tobaccoRadioButton;
	MobileScreenElement declareNoMemHoldCGPolicy;
	MobileScreenElement iAgreeCGBox;
	MobileScreenElement DateOfBirthHealthTExtBox;
	MobileScreenElement yeardropdown;
	MobileScreenElement yearvalue;
	public PremiumCalHealthPage(AppiumDriver driver, String screenName)
	{
		super((AndroidDriver) driver,screenName);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			floaterCoverRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[contains(@text=' Floater')]"),"Floater", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			individualCoverRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text='Individual']"),"Individual", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			proposer1DOBTextField= new MobileScreenElement(By.xpath("//android.widget.Image[@text='icon-calendar' and @bounds='[1148,1036][1224,1112]']"), "DOB", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			thresholdLimitDropDown=new MobileScreenElement(By.xpath("//android.widget.Spinner[@text='Select Threshold Limit' and @resource-id='proposerthresholdLmt']"),"Thershold Limit", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
	        //thresholdLimitDropDown=new MobileScreenElement(MobileBy.AndroidUIAutomator(String.format("new UiSelector().index(6).clickable(true).resource-id(\"proposerthresholdLmt\")")),"Thershold Limit", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			sumInsuredDropDown=new MobileScreenElement(By.xpath("//android.widget.Spinner[@text='Select Sum Insured']"),"Sum Insured", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			termsAndConditionsCheckBox= new MobileScreenElement(By.xpath("//android.widget.CheckBox[@bounds='[64,2020][128,2088]']"), "Terms And Conditions", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			calculatePremiumButton= new MobileScreenElement(By.xpath("//android.widget.Button[@text='Save & Calculate Premium']"), "Calculate Premium", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			addSpouseButton= new MobileScreenElement(By.xpath("//android.view.View[@text='Spouse']//following::android.view.View"), "Add Spouse", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			addChildButton= new MobileScreenElement(By.xpath("//android.widget.Button[@text='Add Child']"), "Add Child", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			planADropDown= new MobileScreenElement(By.xpath("//android.view.View[@text='Plan Type *']//following::android.view.View"), "Plan A", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			spouse1DOBTextField= new MobileScreenElement(By.xpath("//android.widget.EditText[@resource-id='spouseDateOfBirth']"), "Spouse", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			continueButton= new MobileScreenElement(By.xpath("//android.widget.Button[@text='Continue']"), "Continue", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			yearDropdown= new MobileScreenElement(By.xpath("//android.view.View[@text='3']"), "Date of Birth", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			yearOption= new MobileScreenElement(By.xpath("//android.widget.CheckedTextView[@text='1995']"), "Year", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			dateOption= new MobileScreenElement(By.xpath("//android.view.View[@text='21']"), "Date", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			sumInsuredDropDown2=new MobileScreenElement(By.xpath("//android.view.View[@text='Select Sum Insured (in Rs.) *']//following::android.view.View"),"Sum Insured", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			XProposer=new MobileScreenElement(By.xpath("//android.view.View[@text='ADD']"),"Proposer", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			//termsAndConditionsCheckBox2= new MobileScreenElement(By.xpath("//android.view.View[@text='I agree with the ']/preceding::android.widget.CheckBox[1]"), "Terms And Conditions", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			termsAndConditionsCheckBox2= new MobileScreenElement(By.xpath("//android.widget.TextView[@text='I agree to the ']/preceding::android.widget.CheckBox"), "Terms And Conditions", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			okbutton= new MobileScreenElement(By.xpath("//android.widget.Button[@text='OK']"),"OK", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			proposerAdd= new MobileScreenElement(By.xpath("//android.view.View[@text='ADD']"),"Add Proposer", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			sumInsuredCanGuardDropDown= new MobileScreenElement(By.xpath("//android.view.View[@text='Sum Insured (in Rs.) *']//following::android.view.View"),"Sum Insured for Cancer Guard", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			genderMaleCGRadioButton= new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[128,1416][208,1500]']"),"Male", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			smokerRadioButton= new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[620,1624][704,1708]']"),"No to Smoking", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			tobaccoRadioButton= new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[620,1896][704,1980]']"),"No to Tobacco", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			declareNoMemHoldCGPolicy= new MobileScreenElement(By.xpath("//android.widget.CheckBox[@bounds='[84,1732][148,1796]']"),"Declatation CG", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			iAgreeCGBox=new MobileScreenElement(By.xpath("//android.widget.CheckBox[@bounds='[84,1968][148,2036]']"),"I agree", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
	}

	public void fillNewIndiaTopUpMediclaimDetails(PremiumCalEntity premiumCalculator,CustomAssert assertReference ) throws InterruptedException{
		if(premiumCalculator.getAction().equalsIgnoreCase("add")||premiumCalculator.getAction().equalsIgnoreCase("edit")){
			if((premiumCalculator.getStringValueForField("Product").equalsIgnoreCase("New India Top Up"))) {
				if(premiumCalculator.getBooleanValueForField("ConfigFloater")){
					click(floaterCoverRadioButton);
					if(premiumCalculator.getBooleanValueForField("ConfigThresholdLimit")){
						selectValueFromList(thresholdLimitDropDown, premiumCalculator.getStringValueForField("ThresholdLimit"));
					}
					if(premiumCalculator.getBooleanValueForField("ConfigSumInsured")){
						selectValueFromList(sumInsuredDropDown, premiumCalculator.getStringValueForField("SumInsured"));
					}

					if(premiumCalculator.getBooleanValueForField("ConfigFirstMemberDOB")){
						clearAndSendKeys(proposer1DOBTextField, premiumCalculator.getStringValueForField("FirstMemberDOB"));
					}

				}

				else if (premiumCalculator.getBooleanValueForField("ConfigIndividual")){
					click(individualCoverRadioButton);
				try {
						click(XProposer);
					}catch(Exception e) {
						System.out.println(e.getMessage());
					}

					scrollDown();
					try {
					if(premiumCalculator.getBooleanValueForField("ConfigFirstMemberDOB")){
						TouchAction action= new TouchAction(driver);
						action.press(PointOption.point(1158, 958)).release().perform();
						//click(proposer1DOBTextField);
						click(yearDropdown);
						/*//scrollUp();
						//scrollUp();
						//scrollUp();
						TouchAction action=new TouchAction(driver);
						action.longPress(PointOption.point(170,247))
						.moveTo(PointOption.point(200,2423)).release().perform();
												
						TouchAction action1=new TouchAction(driver);
						action1.longPress(PointOption.point(170,247))
						.moveTo(PointOption.point(200,2423)).release().perform();
						click(yearOption);
						click(dateOption);*/
					}
					}
					catch(Exception e)
					{
						System.out.println(e.getMessage());
					}
					//scrollDown();
					//scrollToElementForward();
					if(premiumCalculator.getBooleanValueForField("ConfigThresholdLimit")){
						//touchactionClick(thresholdLimitDropDown);
						/*
						TouchAction action= new TouchAction(driver);
						action.press(PointOption.point(1158, 958)).release().perform();*/
						
						String Amount=premiumCalculator.getStringValueForField("ThresholdLimit");
						//thresholdRadioButton1=new MobileScreenElement(By.xpath("//android.widget.CheckedTextView[@text="+"'"+Amount+"'"+"]"), "Threshold amount", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
						thresholdRadioButton1=new MobileScreenElement(By.xpath("//android.view.View[@text='Threshold Limit (in Rs.) *']//following::android.view.View"), "Threshold amount", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
						click(thresholdRadioButton1);
						thresholdRadioButton2=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+Amount+"'"+"]"), "Threshold amount", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
						click(thresholdRadioButton2);
						click(okbutton);
						//selectValueFromList(thresholdLimitDropDown, topUpMediclaimEntity.getStringValueForField("ThresholdLimit"));
					}
					if(premiumCalculator.getBooleanValueForField("ConfigSumInsured")){
						//touchactionClick(sumInsuredDropDown);
						
						TouchAction action= new TouchAction(driver);
						action.press(PointOption.point(1156, 1315
								)).release().perform();
						
						String SIAmount=premiumCalculator.getStringValueForField("SumInsured");
						/*SIRadioButton1=new MobileScreenElement(By.xpath("//android.view.View[@text='Sum Insured (in Rs.) *']//following::android.view.View"), "Sum Insured amount", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
						click(SIRadioButton1);*/
						SIRadioButton2=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+SIAmount+"'"+"]"), "Sum Insured amount", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
						click(SIRadioButton2);
						click(okbutton);
						//selectValueFromList(sumInsuredDropDown, topUpMediclaimEntity.getStringValueForField("SumInsured"));

					}		
				}
			}
			if((premiumCalculator.getStringValueForField("Product").equalsIgnoreCase("New India Cancer Guard Policy"))) {
				if(premiumCalculator.getBooleanValueForField("configProposerAddDropDown")) {
					click(proposerAdd);
					try {
						if(premiumCalculator.getBooleanValueForField("ConfigFirstMemberDOB")){
							TouchAction action= new TouchAction(driver);
							action.press(PointOption.point(1158, 958)).release().perform();
							//click(proposer1DOBTextField);
							click(yearDropdown);
							/*//scrollUp();
							//scrollUp();
							//scrollUp();
							TouchAction action=new TouchAction(driver);
							action.longPress(PointOption.point(170,247))
							.moveTo(PointOption.point(200,2423)).release().perform();
													
							TouchAction action1=new TouchAction(driver);
							action1.longPress(PointOption.point(170,247))
							.moveTo(PointOption.point(200,2423)).release().perform();
							click(yearOption);
							click(dateOption);*/
						}
						}
						catch(Exception e)
						{
							System.out.println(e.getMessage());
						}
					if(premiumCalculator.getBooleanValueForField("ConfigSumInsured")){
						click(sumInsuredCanGuardDropDown);
						String SIAmount=premiumCalculator.getStringValueForField("SumInsured");
						SIRadioButton1=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+SIAmount+"'"+"]"), "Sum Insured amount", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
						click(SIRadioButton1);
						click(okbutton);
				}
					//genderMaleCGRadioButton configGenderMale
					if(premiumCalculator.getBooleanValueForField("configGenderMale")){
						click(genderMaleCGRadioButton);
					}
				//smokerRadioButton tobaccoRadioButton
					if(premiumCalculator.getBooleanValueForField("configSmoker")){
						click(smokerRadioButton);
					} 	
					if(premiumCalculator.getBooleanValueForField("configTobacco")){
						click(tobaccoRadioButton);
					} 
					scrollDown();
					click(declareNoMemHoldCGPolicy);
					Thread.sleep(1000);
					click(iAgreeCGBox);
				}	
			}

			if((premiumCalculator.getStringValueForField("Product").equalsIgnoreCase("New India Premier Mediclaim Policy"))) {
				if (premiumCalculator.getBooleanValueForField("ConfigIndividual")){
					click(individualCoverRadioButton);
				}
				if(premiumCalculator.getBooleanValueForField("ConfigPlanA")){
					click(planADropDown);
					String planA=premiumCalculator.getStringValueForField("PlanA");
					planARadioButton1=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+planA+"'"+"]"), "Plan A", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
					click(planARadioButton1);
					click(okbutton);
					//selectValueFromList(sumInsuredDropDown, topUpMediclaimEntity.getStringValueForField("SumInsured"));
					if(premiumCalculator.getBooleanValueForField("ConfigSumInsured")){
						click(sumInsuredCanGuardDropDown);
						String SIAmount=premiumCalculator.getStringValueForField("SumInsured");
						SIRadioButton1=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+SIAmount+"'"+"]"), "Sum Insured amount", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
						click(SIRadioButton1);
						click(okbutton);
						//selectValueFromList(sumInsuredDropDown, topUpMediclaimEntity.getStringValueForField("SumInsured"));

					}

					try {
						if(premiumCalculator.getBooleanValueForField("ConfigDateOfBirthTExtBox")){
							click(DateOfBirthHealthTExtBox);
							click(yeardropdown);
							//scrollUp();
							//scrollUp();
							//scrollUp();
							TouchAction action=new TouchAction(driver);
							action.longPress(PointOption.point(170,247))
							.moveTo(PointOption.point(200,2423)).release().perform();
							Thread.sleep(2000);
							
							TouchAction action1=new TouchAction(driver);
							action1.longPress(PointOption.point(170,247))
							.moveTo(PointOption.point(200,2423)).release().perform();
							click(yearvalue);
							click(dateOption);
							//	click(okButton);
						}
						}
						catch(Exception e) {
							System.out.println(e.getMessage());
						}
				}		
				else if(premiumCalculator.getBooleanValueForField("ConfigPlanB")){
				}
			}

			if((premiumCalculator.getStringValueForField("Product").equalsIgnoreCase("New India Mediclaim"))) {
				if(premiumCalculator.getBooleanValueForField("ConfigFirstMemberDOB")){
					clearAndSendKeys(proposer1DOBTextField, premiumCalculator.getStringValueForField("FirstMemberDOB"));
				}
				if(premiumCalculator.getBooleanValueForField("ConfigSumInsured")){
					click(sumInsuredDropDown);
					String SIAmount=premiumCalculator.getStringValueForField("SumInsured");
					SIRadioButton1=new MobileScreenElement(By.xpath("//android.widget.CheckedTextView[@text="+"'"+SIAmount+"'"+"]"), "Sum Insured amount", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
					click(SIRadioButton1);
					//selectValueFromList(sumInsuredDropDown, topUpMediclaimEntity.getStringValueForField("SumInsured"));

				}	
			}
			if((premiumCalculator.getStringValueForField("Product").equalsIgnoreCase("New India Floater Mediclaim"))) {
				if(premiumCalculator.getBooleanValueForField("ConfigSumInsured")){
					/*scrollToElementBackward();*/
					click(sumInsuredDropDown2);
					String SIAmount=premiumCalculator.getStringValueForField("SumInsured");
					SIRadioButton1=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+SIAmount+"'"+"]"), "Sum Insured amount", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
					click(SIRadioButton1);
					click(okbutton);
					/*scrollToElementForward();*/
					scrollDown();
					try {
						click(XProposer);
					}catch(Exception e) {
						System.out.println(e.getMessage());
					}
					try {
					if(premiumCalculator.getBooleanValueForField("ConfigFirstMemberDOB")){
						click(proposer1DOBTextField);
						click(yearDropdown);
						/*scrollToElementBackward();
						scrollToElementBackward();
						scrollToElementBackward();*/
						TouchAction action=new TouchAction(driver);
						action.longPress(PointOption.point(170,247))
						.moveTo(PointOption.point(200,2423)).release().perform();
						
						TouchAction action1=new TouchAction(driver);
						action1.longPress(PointOption.point(170,247))
						.moveTo(PointOption.point(200,2423)).release().perform();
						
						click(yearOption);
						click(dateOption);
					}
					}
					catch(Exception e){
						System.out.println(e.getMessage());
					}
					if(premiumCalculator.getBooleanValueForField("ConfigSpousebu")){
					click(addSpouseButton);
					}
					try {
					if(premiumCalculator.getBooleanValueForField("ConfigSpouseDob")){
						click(spouse1DOBTextField);
						click(yearDropdown);
						TouchAction action=new TouchAction(driver);
						action.longPress(PointOption.point(170,247))
						.moveTo(PointOption.point(200,2423)).release().perform();
						
						TouchAction action1=new TouchAction(driver);
						action1.longPress(PointOption.point(170,247))
						.moveTo(PointOption.point(200,2423)).release().perform();
						click(yearOption);
						click(dateOption);
					}
					}
					catch(Exception e) {
						System.out.println(e.getMessage());
					}
				}	
				
				
			}
			if((premiumCalculator.getStringValueForField("Product").equalsIgnoreCase("New India Asha Kiran"))) {
			}		
		}
	}

	public void checkTermsAndConditions(PremiumCalEntity premiumCalculator,CustomAssert assertReference ) throws InterruptedException{
		if(premiumCalculator.getBooleanValueForField("ConfigTermsAndConditions")){
			//scrollToElementForward();
			check(termsAndConditionsCheckBox);
			//scrollToElementForward();
		}
	}
	
	
	
	public void checkTermsAndConditions2(PremiumCalEntity premiumCalculator,CustomAssert assertReference ) throws InterruptedException{
		if(premiumCalculator.getBooleanValueForField("ConfigTermsAndConditio")){
			scrollDown();
			Thread.sleep(2000);
			click(termsAndConditionsCheckBox2);
		}
	}
	
	
	public void clickOnContinueButton(PremiumCalEntity premiumCalculator,CustomAssert assertReference ) throws InterruptedException{
		if(premiumCalculator.getBooleanValueForField("ConfigContinue")){
			scrollDown();
			click(continueButton);
		}
	}

	public void clickOnCalculatePremium(PremiumCalEntity premiumCalculator,CustomAssert assertReference ) throws InterruptedException{
		if(premiumCalculator.getBooleanValueForField("ConfigCalculatePremium")){
			click(calculatePremiumButton);
		}
	}

	public void fillAndSubmitPremiumCalculDetails(PremiumCalEntity premiumCalculator,CustomAssert assertReference,String stepGroup) throws InterruptedException{
		if(isConfigTrue(premiumCalculator.getConfigExecute()))		
		{
			fillNewIndiaTopUpMediclaimDetails(premiumCalculator, assertReference);
			checkTermsAndConditions(premiumCalculator, assertReference);
			checkTermsAndConditions2(premiumCalculator, assertReference);
			clickOnCalculatePremium(premiumCalculator, assertReference);
			clickOnContinueButton(premiumCalculator, assertReference);

		}
	}
}