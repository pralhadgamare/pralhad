package com.aqm.staf.library.pages.common;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import com.aqm.framework.constant.WaitType;
import com.aqm.framework.core.CustomAssert;
import com.aqm.framework.core.MobileScreen;
import com.aqm.framework.core.MobileScreenElement;
import com.aqm.testing.testDataEntity.PolicyInfoIntermidiaryEntity;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.offset.PointOption;

public class PolicyHolderInformationIntermidiarypage extends MobileScreen { 

	MobileScreenElement monthLabel;
	MobileScreenElement YearLabel;
	MobileScreenElement dateLabel;
	MobileScreenElement monthRadioButton;
	MobileScreenElement YearRadioButton;
	MobileScreenElement NewCustomerRadioButton;
	MobileScreenElement FirstNameTextBox;
	MobileScreenElement MiddleNameTextBox;
	MobileScreenElement LastNameTextBox;
	MobileScreenElement GenderMaleRadioButton;
	MobileScreenElement DateOfBirthTExtBox;
	MobileScreenElement BuildingnoStreetTextBox;
	MobileScreenElement GstRegestrationIDDropDown;
	MobileScreenElement GstIntextbox;
	MobileScreenElement StateTextBox;
	MobileScreenElement pincodeTextBox;
	MobileScreenElement CityTextBox;
	MobileScreenElement MobileNumberTextBox;
	MobileScreenElement EmailIDTextBox;
	MobileScreenElement PanNOTextBox;
	MobileScreenElement EinsurenceAccountNotextField;
	MobileScreenElement NextButton;
	MobileScreenElement CreateButton;
	MobileScreenElement yeardropdown;
	MobileScreenElement yearvalue;
	MobileScreenElement dayvalue;
	MobileScreenElement GstRegestrationIDDropDownvalue;
	MobileScreenElement StateNameLable;
	MobileScreenElement Statename;
	MobileScreenElement PinNoTExtField;
	MobileScreenElement AlertText;
	MobileScreenElement individualeRadioButton;
	MobileScreenElement GstRegestrationIDRadioButton1;
	MobileScreenElement FirstNameHealthTextBox;
	MobileScreenElement MiddleNameHealthTextBox;
	MobileScreenElement LastNameHealthTextBox;
	MobileScreenElement GenderMaleHealthRadioButton;
	MobileScreenElement DateOfBirthHealthTExtBox;
	MobileScreenElement BuildingnoStreetHealthTextBox;
	MobileScreenElement GstRegestrationIDHealthDropDown;
	MobileScreenElement GstInHealthtextbox;
	MobileScreenElement StateHealthTextBox;
	MobileScreenElement pincodeHealthTextBox;
	MobileScreenElement MobileNumberHealthTextBox;
	MobileScreenElement CityHealthTextBox;
	MobileScreenElement EmailIDHealthTextBox;
	MobileScreenElement PanNoHealthTextBox;
	MobileScreenElement proceedButton;
	MobileScreenElement editButton;
	MobileScreenElement proposerNameTextfield;
	MobileScreenElement proposerOccupationDropDown;
	MobileScreenElement proposerOccupationRadioButton1;
	MobileScreenElement nomineeNameTextfield;
	MobileScreenElement nomineeRelationRadioButton1;
	MobileScreenElement nomineeRelationDropDown;
	MobileScreenElement yesRadioButton;
	MobileScreenElement noRadioButton;
	MobileScreenElement saveAndRecalculateButton;
	MobileScreenElement StateHealthname;
	MobileScreenElement PinNoHealthTextField;
	MobileScreenElement dateOption;
	MobileScreenElement saveButton;
	MobileScreenElement NextbuttonHm;
	MobileScreenElement proposerIdTextfield;
	MobileScreenElement proposerNatureOfIdRadioButton1;
	MobileScreenElement proposerHeightTextfield;
	MobileScreenElement proposerWeightTextfield;
	MobileScreenElement proposerNatureOfIdDropDown;
	MobileScreenElement saveAndCalculateButton;
	MobileScreenElement StateMotorTextBox;
	MobileScreenElement pincodeMotorTextBox;
	MobileScreenElement okButton;
	MobileScreenElement FristNameHealthTextBox1;
	MobileScreenElement LastNameHealthHelthTextBox1;
	MobileScreenElement BuildingnoStreetHealth3TextBox;
	MobileScreenElement GstRegestrationIDDropDownHelth;
	MobileScreenElement GstRegestrationIDDrophealthvalueDown;
	MobileScreenElement GstInHealth3TextBox;
	MobileScreenElement pinCodeMotorLabel;
	MobileScreenElement StateHealth3TextBox;
	MobileScreenElement PinCodeHealth3TExtBox;
	MobileScreenElement CityHealth3TextBox;
	MobileScreenElement MobileNoHealth3TExtField;
	MobileScreenElement SpouseNameTextfield;
	MobileScreenElement SpouseOccupation;
	MobileScreenElement RelationWithNomineeDropDown;
	MobileScreenElement SaveAndRECalculatePrimiumHelth3Button;
	MobileScreenElement nextHAAButton;
	MobileScreenElement nationalityButton;
	MobileScreenElement indianButton;
	MobileScreenElement nationalityButton1;
	MobileScreenElement continueButton;
	MobileScreenElement proposerButton;
	MobileScreenElement spouseButton;
	MobileScreenElement GenderFemaleHealthRadioButton;
	MobileScreenElement noRadioButton1;
	MobileScreenElement preExistingDisTextField;
	MobileScreenElement IDDocNoTextfield;
	MobileScreenElement bladderhabitsRadioButton;
	MobileScreenElement soreRadioButton;
	MobileScreenElement unusualBleedingRadioButton;
	MobileScreenElement lumpInBreastRadioButton;
	MobileScreenElement persistentIndigestionRadioButton;
	MobileScreenElement wartOrMoleRadioButton;
	MobileScreenElement coughOrHoarsenessRadioButton;
	MobileScreenElement abnormalWeightLossRadioButton;
	MobileScreenElement chemotherapyRadiotherapyRadioButton;
	MobileScreenElement parentsSiblingsCancerRadioButton;
	MobileScreenElement appointeeNameTextfield;
	MobileScreenElement relationAppointeeTextfield;


	public PolicyHolderInformationIntermidiarypage(AppiumDriver driver, String screenName)
	{
		super((AndroidDriver) driver,screenName);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			dateLabel= new MobileScreenElement(By.xpath("//android.view.View[@text='10']"),"Date", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			individualeRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text='Individual']"), "Individual", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			NewCustomerRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text='New Customer' and @index='0']"),"New Customer", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			FirstNameTextBox=new MobileScreenElement(By.xpath("//android.view.View[@index='6']/following::android.widget.EditText[1]"), "This is first Name");
					//new MobileScreenElement(By.xpath("//android.widget.EditText[@text='First Name']//following::android.widget.EditText[1]"),"First Name", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 20);
			MiddleNameTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='Last Name *' and @index='9']//preceding::android.widget.EditText"),"Enter value of jewellery", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			LastNameTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='Last Name *']//following::android.widget.EditText"),"Last Name", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			preExistingDisTextField=new MobileScreenElement(By.xpath("//android.view.View[@text='Pre-Existing Disease *']//following::android.widget.EditText"),"Pre-Existing Disease DropDown", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			DateOfBirthTExtBox=new MobileScreenElement(By.xpath("//android.widget.Image[@text='icon-calendar' and @bounds='[1212,504][1288,584]']"),"Date of Birth", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			BuildingnoStreetTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='Building No. Street *']//following::android.widget.EditText"),"Building No. Street", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			GstRegestrationIDDropDown=new MobileScreenElement(By.xpath("//android.view.View[@text='GST Registration ID Type']"),"GST Registration ID", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			GstIntextbox=new MobileScreenElement(By.xpath("//android.view.View[@text='GSTIN*']//following::android.widget.EditText[1]"),"GST IN", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			StateTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='State *']//following::android.widget.EditText"),"State", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			pincodeTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='PIN Code *']//following::android.widget.EditText"),"Pin code", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			CityTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='City *' and @index='26']//following::android.widget.EditText[1]"),"Buy Online", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			MobileNumberTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='Mobile Number *']//following::android.widget.EditText"),"Mobile Number", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			EmailIDTextBox=new MobileScreenElement(By.xpath("android.view.View[@text='Email ID' and @index='30']//following::android.widget.EditText"),"Buy Online", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			PanNOTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='PAN No.']//following::android.widget.EditText"),"Pan No.", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			EinsurenceAccountNotextField=new MobileScreenElement(By.xpath("android.view.View[@text='E-Insurance Account No.' and @index='34']//following::android.widget.EditText"),"E-Insurance Account No", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			NextButton=new MobileScreenElement(By.xpath("//android.widget.Button[@text='Next']"),"Next", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			CreateButton=new MobileScreenElement(By.xpath("//android.widget.Button[@text='Create']"),"Create", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			yeardropdown=new MobileScreenElement(By.xpath("//android.widget.Button[@text='2002 arrow dropdown']"),"Year", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			yearvalue=new MobileScreenElement(By.xpath("//android.widget.CheckedTextView[@text='1995']"),"value", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			dayvalue=new MobileScreenElement(By.xpath("//android.view.View[@text='8']"),"value", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			GstRegestrationIDDropDownvalue=new MobileScreenElement(By.xpath("//android.widget.CheckedTextView[@text='GST Registration ID Type' and resource-id='android:id/text1']"),"Normal,Composite,Casual", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			AlertText=new MobileScreenElement(By.xpath("//android.widget.Button[@text='ok']//preceding::android.widget.TextView[1]"),"Buy Online", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			FirstNameHealthTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='First Name *']//following::android.widget.EditText"),"First Name", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			MiddleNameHealthTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='Middle Name']//following::android.widget.EditText"),"Middle Name", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			LastNameHealthTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='Last Name *']//following::android.widget.EditText"),"Last Name", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			GenderMaleHealthRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[64,1772][144,1856]']"),"Male", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			DateOfBirthHealthTExtBox=new MobileScreenElement(By.xpath("//android.widget.EditText[@resource-id='dateOfBirth']"),"Date Of Birthday", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			BuildingnoStreetHealthTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='Building No. Street *']//following::android.widget.EditText"),"Building No and Street", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			GstRegestrationIDHealthDropDown=new MobileScreenElement(By.xpath("//android.widget.Spinner[@text='GST Registration ID Type']"),"GST Registration Id", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			GstInHealthtextbox=new MobileScreenElement(By.xpath("//android.view.View[@text='GSTIN*']//following::android.widget.EditText"),"GSTIN", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			StateHealthTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='State *']//following::android.widget.EditText"),"State", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			StateMotorTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='State *']//following::android.widget.EditText"),"State", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			pincodeMotorTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='PIN Code *']//following::android.widget.EditText"),"Pincode", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			pincodeHealthTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='PIN Code *']//following::android.widget.EditText"),"Pincode", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			MobileNumberHealthTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='Mobile No.*']//following::android.widget.EditText"),"Mobile Number", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			CityHealthTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='City *']//following::android.widget.EditText"),"City", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);	
			EmailIDHealthTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='E-mail ID']//following::android.widget.EditText"),"Email Id", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);	
			PanNoHealthTextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='PAN No.']//following::android.widget.EditText"),"Pan No", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);	
			proceedButton=new MobileScreenElement(By.xpath("//android.view.View[@text='Edit']//following::android.view.View"),"Proceed", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);	
			editButton=new MobileScreenElement(By.xpath("//android.view.View[@text='Select']//following::android.view.View"),"Edit", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);	
			proposerNameTextfield=new MobileScreenElement(By.xpath("//android.widget.EditText[@resource-id='idDocNoProposerDetails0']"),"Proposer Name", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			proposerOccupationDropDown=new MobileScreenElement(By.xpath("//android.view.View[@text='Occupation *']//following::android.view.View"),"Proposer Occupation", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			nomineeNameTextfield=new MobileScreenElement(By.xpath("//android.view.View[@text='Nominee Name *']//following::android.widget.EditText"),"Nominee Name", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			nomineeRelationDropDown=new MobileScreenElement(By.xpath("//android.view.View[@text='Relationship with the Nominee *']//following::android.view.View"),"Nominee Relation", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			yesRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text='Yes']"),"Yes", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			noRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[524,2144][604,2228]']"),"No", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			saveAndRecalculateButton=new MobileScreenElement(By.xpath("//android.widget.Button[@text='Save & Re-Calculate Premium']"),"Save & Re-caculate Premium", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			StateHealthname=new MobileScreenElement(By.xpath("//android.view.View[@text='MAHARASHTRA']"),"State Name", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			//PinNoHealthTextField=new MobileScreenElement(By.xpath("//android.widget.EditText[@text='400066']"),"Pincode Number", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			NextbuttonHm=new MobileScreenElement(By.xpath("//android.widget.Button[@text='Next']"),"next", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			dateOption= new MobileScreenElement(By.xpath("//android.view.View[@text='21']"), "Date", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			saveButton=new MobileScreenElement(By.xpath("//android.widget.Button[@text='Save']"),"Save", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			NextbuttonHm=new MobileScreenElement(By.xpath("//android.widget.Button[@text='Next']"),"next", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			proposerHeightTextfield=new MobileScreenElement(By.xpath("//android.view.View[@text='Height (Meters) *']//following::android.widget.EditText"),"Proposer Height", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			proposerWeightTextfield=new MobileScreenElement(By.xpath("//android.view.View[@text='Weight (Kg) *']//following::android.widget.EditText"),"Proposer Weight", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			proposerNatureOfIdDropDown=new MobileScreenElement(By.xpath("//android.view.View[@text='Nature of ID *']//following::android.view.View"),"Nature of Id", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			proposerIdTextfield=new MobileScreenElement(By.xpath("//android.widget.EditText[@resource-id='idDocNo']"),"Id Number", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			saveAndCalculateButton=new MobileScreenElement(By.xpath("//android.widget.Button[@text='Save & Calculate Premium']"),"Save & Calculate Premium", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			okButton=new MobileScreenElement(By.xpath("//android.widget.Button[@text='OK']"),"Ok", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			FristNameHealthTextBox1=new MobileScreenElement(By.xpath("//android.view.View[@text='First Name *']//following::android.widget.EditText"),"Frist Name", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);  
			LastNameHealthHelthTextBox1=new MobileScreenElement(By.xpath("//android.view.View[@text='Last Name *']//following::android.widget.EditText"),"Last Name", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			BuildingnoStreetHealth3TextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='Building No. Street *']//following::android.widget.EditText"),"Building No and Street", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			GstRegestrationIDDropDownHelth=new MobileScreenElement(By.xpath("//android.widget.Spinner[@text='Select Registration ID Type']"),"GST Registration ID Type", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			GstRegestrationIDDrophealthvalueDown=new MobileScreenElement(By.xpath("//android.widget.Button[@text='GST Registration ID Type']"),"GST Registration ID Type", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			GstInHealth3TextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='GSTIN']//following::android.widget.EditText[1]"),"Gst In", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			pinCodeMotorLabel=new MobileScreenElement(By.xpath("//android.view.View[@text='400006']"),"Pin Code", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
			StateHealth3TextBox=new MobileScreenElement(By.xpath("//android.view.View[@text='State *']//following::android.widget.EditText"),"State Text Box", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			PinCodeHealth3TExtBox=new MobileScreenElement(By.xpath("//android.view.View[@text='PIN Code *']//following::android.widget.EditText"),"Pin Code", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			CityHealth3TextBox= new MobileScreenElement(By.xpath("//android.view.View[@text='City']//following::android.widget.EditText[1]"),"Pin Code", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			MobileNoHealth3TExtField=new MobileScreenElement(By.xpath("//android.view.View[@text='Mobile Number *']//following::android.widget.EditText"),"Mobile Number", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			//SpouseNameTextfield=new MobileScreenElement(By.xpath("//android.view.View[@text='Relationship with proposer*']//preceding::android.widget.EditText[1]"),"Mobile Number", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			SpouseNameTextfield=new MobileScreenElement(By.xpath("//android.view.View[@text='Name *']//following::android.widget.EditText"),"Spouse Name", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			SpouseOccupation=new MobileScreenElement(By.xpath("//android.widget.Spinner[@text='Select your Occupation']"),"Spouse Occupation", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			RelationWithNomineeDropDown=new MobileScreenElement(By.xpath("//android.view.View[@text='Relationship with the Nominee *']//following::android.view.View"),"Relation With Nominee", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
			SaveAndRECalculatePrimiumHelth3Button=new MobileScreenElement(By.xpath("//android.widget.Button[@text='Save & Re-caculate Premium']"),"Save And RECalculate Primium Helth", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			nationalityButton= new MobileScreenElement(By.xpath("//android.view.View[@text='Nationality *']"),"Nationality", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			indianButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text='Indian' and @index='1']"),"Indian", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			continueButton=new MobileScreenElement(By.xpath("//android.widget.Button[@text='Continue']"),"Continue", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			proposerButton=new MobileScreenElement(By.xpath("//android.view.View[@text='Proposer']"),"Proposer", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			spouseButton=new MobileScreenElement(By.xpath("//android.view.View[@text='Spouse']"),"Spouse", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			GenderFemaleHealthRadioButton= new MobileScreenElement(By.xpath("//android.widget.RadioButton[@index='0']//following::android.widget.TextView[Female]"),"Female", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			noRadioButton1=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[524,2340][604,2424]']"),"No", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			IDDocNoTextfield= new MobileScreenElement(By.xpath("//android.view.View[@text='ID Doc No *']//following::android.widget.EditText"),"ID Doc No", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			bladderhabitsRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[620,1136][704,1220]']"),"No to Bladder Habits", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			soreRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[620,1432][704,1516]']"),"No to A sore anywhere on the body that does or did not heal within a fortnight?", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			unusualBleedingRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[620,1728][704,1812]']"),"No to Unusual bleeding or discharge of any kind from any body-opening ?", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			lumpInBreastRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[620,2024][704,2108]']"),"No to Thickening or lump in the breast or anywhere else in the body ?", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			persistentIndigestionRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[620,2320][704,2404]']"),"No to Persistent indigestion or difficulty or obstruction in swallowing for over a fortnight ?", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			wartOrMoleRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[620,1128][704,1212]']"),"No to Any obvious change in a wart or mole such as shape, size, Colour, discharge or bleeding ?", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			coughOrHoarsenessRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[620,1360][704,1444]']"),"No to Cough or hoarseness, for a fortnight ", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			abnormalWeightLossRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[620,1656][704,1740]']"),"No to Have you experienced any abnormal weight loss in the past two years (5kg or more)", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			chemotherapyRadiotherapyRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[620,2016][704,2100]']"),"No to Ever been diagnosed with, operated for, investigated for or underwent chemotherapy/ Radiotherapy for any reason whatsoever", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			parentsSiblingsCancerRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@bounds='[620,2312][704,2396]"),"No to Has any of your parents or siblings ever been diagnosed with any form of cancer", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			appointeeNameTextfield=new MobileScreenElement(By.xpath("//android.view.View[@text='Appointee Name *']//following::android.widget.EditText"),"Appointee Name", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			relationAppointeeTextfield=new MobileScreenElement(By.xpath("//android.view.View[@text='Relationship of Appointee with Policy holder *']//following::android.widget.EditText"),"Appointee Name", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
			
			
	}

	public void fillAndsubmitpolicyholderInformation(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity,CustomAssert assertReference ) throws Exception{
		if(policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("add")||policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("edit")){
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("HomeAndAccident"))||policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Motor")) {

				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigNewCustomerRadioButton")){
					clearAndSendKeys(NewCustomerRadioButton, policyInfoIntermidiaryEntity.getStringValueForField("newCustomerRadioButton"));
				}
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigIndividual")){
					click(individualeRadioButton);
				}

				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigFirstNameTextBox")){
					//System.out.println(FirstNameTextBox.getText());
					//clearAndSendKeys(FirstNameTextBox, policyInfoIntermidiaryEntity.getStringValueForField("FirstNameTextBox"));
					//driver.findElement(By.xpath("(//android.view.View[starts-with(@text,'First Name')]//following-sibling::view)[1]//android.widget.EditText")).sendKeys("Dhwani");
				driver.findElement(By.xpath("//android.view.View[@text='First Name *']//following::android.widget.EditText")).sendKeys("ABC");
				}

				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigMiddleNameTextBox")){
					clearAndSendKeys(MiddleNameTextBox, policyInfoIntermidiaryEntity.getStringValueForField("MiddleNameTextBox"));
				}

				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigLastNameTextBox")){
					clearAndSendKeys(LastNameTextBox, policyInfoIntermidiaryEntity.getStringValueForField("lastNameTextBox"));
				}


				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigGenderMaleRadioButton")){
					//GenderMaleRadioButton=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@index='0']//following::android.view.View[1]"),"Male", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
					GenderMaleRadioButton=new MobileScreenElement(By.xpath("//*[@class='android.widget.RadioButton' and @bounds='[64,1772][144,1856]']"),"Male", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
					click(GenderMaleRadioButton);
					
				}
				scrollDown();
				try {
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigDateOfBirthTExtBox")){
					//DateOfBirthTExtBox=new MobileScreenElement(By.xpath("//*[@class='android.view.View' and @bounds='[64,420][1000,512]']"),"Date of Birth", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);
					
					click(DateOfBirthTExtBox);
					click(yeardropdown);
					TouchAction action=new TouchAction(driver);
					action.longPress(PointOption.point(170,247))
					.moveTo(PointOption.point(200,2423)).release().perform();
											
					TouchAction action1=new TouchAction(driver);
					action1.longPress(PointOption.point(170,247))
					.moveTo(PointOption.point(200,2423)).release().perform();
					//scrollToElementBackward();
					click(yearvalue);
					click(dayvalue);
				}
				/*if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigDateOfBirthMotor")) {
					click(DateOfBirthTExtBox);
					click(monthLabel);
					String month=policyInfoIntermidiaryEntity.getStringValueForField("Month");
					click(monthRadioButton);
					click(YearLabel);
					String year=policyInfoIntermidiaryEntity.getStringValueForField("Year");
					YearRadioButton=new MobileScreenElement(By.xpath("//android.widget.CheckedTextView[@text="+"'"+year+"'"+"]"), "Year", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
					click(YearRadioButton);
					click(dateLabel);
				}*/
				}
				catch(Exception e) {
					System.out.println(e.getMessage());
				}
				
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigNationality")){
					click(nationalityButton);
					click(indianButton);
					click(okButton);
				}
				
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigBuildingnoStreetTextBox")){
					clearAndSendKeys(BuildingnoStreetTextBox, policyInfoIntermidiaryEntity.getStringValueForField("BuildingnoStreetTextBo"));
				}


				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigGstRegestrationIDDropDown")){
					click(GstRegestrationIDDropDown);
					/*click(GstRegestrationIDDropDownvalue);*/
					String gstval=policyInfoIntermidiaryEntity.getStringValueForField("GstRegestrationIDDropDown");
					GstRegestrationIDDropDownvalue= new MobileScreenElement(By.xpath("//android.widget.CheckedTextView[@text="+"'"+gstval+"'"+"]"),"GST Value", false, WaitType.WAITFORELEMENTTOBEEENABLED,10);
					click(GstRegestrationIDDropDownvalue);
					scrollDown();

				}

				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigGstIntextbox")){
					clearAndSendKeys(GstIntextbox, policyInfoIntermidiaryEntity.getStringValueForField("GstIntextbox"));
					
				}


				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigStateTextBox")){
					clearAndSendKeys(StateTextBox, policyInfoIntermidiaryEntity.getStringValueForField("State"));
					Thread.sleep(3000);
					String StateName=policyInfoIntermidiaryEntity.getStringValueForField("StateFull");
					Statename=new MobileScreenElement(By.xpath("//android.view.View[@text='MAHARASHTRA' and @index='0']"), "MAHARASHTRA", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
					click(Statename);
					
				}
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigpincodeTextBox")){
					click(pincodeTextBox);
					clearAndSendKeys(pincodeTextBox, policyInfoIntermidiaryEntity.getStringValueForField("pin"));
					Thread.sleep(3000);
					String pinNo=policyInfoIntermidiaryEntity.getStringValueForField("pinFull");
					PinNoTExtField=new MobileScreenElement(By.xpath("//android.view.View[@text='400066']"), "400066", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
					click(PinNoTExtField);
				}
				scrollDown();
				if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Motor"))){
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigStateMotorTextBox")){				
						clearAndSendKeys(StateMotorTextBox, policyInfoIntermidiaryEntity.getStringValueForField("State"));
						click(StateHealthname);
						scrollToElementForward();
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigpincodeMotorTextBox")){
						click(pincodeMotorTextBox);

						/*clearAndSendKeys(pincodeMotorTextBox, policyInfoIntermidiaryEntity.getStringValueForField("pin"));
						String pinNo=policyInfoIntermidiaryEntity.getStringValueForField("pinFull");
						PinNoTExtField=new MobileScreenElement(By.xpath("//android.view.View[@text="+"'"+pinNo+"'"+"]"), "Make", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
						click(PinNoTExtField);*/

						clearAndSendKeys(pincodeMotorTextBox, policyInfoIntermidiaryEntity.getStringValueForField("pin"));
						//sendKeys(PinNoHealthTextField,("pin"));
						TouchAction action1 = new TouchAction(driver);
						action1.press(PointOption.point(130,930)).release().perform();
						
					}
				}


				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigCityTextBox")){
					clearAndSendKeys(CityTextBox, policyInfoIntermidiaryEntity.getStringValueForField("CityTextBox"));
				}
				scrollDown();
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigMobileNumberTextBox")){
					click(MobileNumberTextBox);
					clearAndSendKeys(MobileNumberTextBox, policyInfoIntermidiaryEntity.getStringValueForField("MobileNumberTextBox"));
				}

				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigEmailIDTextBox")){
					clearAndSendKeys(EmailIDTextBox, policyInfoIntermidiaryEntity.getStringValueForField("EmailIDTextBox"));
				}

				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigPanNOTextBox")){
				clearAndSendKeys(PanNOTextBox, policyInfoIntermidiaryEntity.getStringValueForField("PanNOTextBox"));
				}
			}
		}
		if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health")))  {	
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigFirstNameTextBox")){
				clearAndSendKeys(FirstNameHealthTextBox, policyInfoIntermidiaryEntity.getStringValueForField("FirstNameTextBox"));
			}
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigMiddleNameTextBox")){
				clearAndSendKeys(MiddleNameHealthTextBox, policyInfoIntermidiaryEntity.getStringValueForField("MiddleNameTextBox"));
			}
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigLastNameTextBox")){
				clearAndSendKeys(LastNameHealthTextBox, policyInfoIntermidiaryEntity.getStringValueForField("lastNameTextBox"));
			}

			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigGenderMaleRadioButton")){
				click(GenderMaleHealthRadioButton);
			}
			scrollToElementForward();
			try {
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigDateOfBirthTExtBox")){
				click(DateOfBirthHealthTExtBox);
				click(yeardropdown);
				//scrollUp();
				//scrollUp();
				//scrollUp();
				TouchAction action=new TouchAction(driver);
				action.longPress(PointOption.point(170,247))
				.moveTo(PointOption.point(200,2423)).release().perform();
				Thread.sleep(2000);
				
				TouchAction action1=new TouchAction(driver);
				action1.longPress(PointOption.point(170,247))
				.moveTo(PointOption.point(200,2423)).release().perform();
				click(yearvalue);
				click(dateOption);
				//	click(okButton);
			}
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
			
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigNationality")){
				click(nationalityButton);
				String Nationality= policyInfoIntermidiaryEntity.getStringValueForField("Nationality");
				nationalityButton1=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+Nationality+"'"+"]"), "Nationality", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
				click(nationalityButton1);
				click(okButton);
			}
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigBuildingnoStreetTextBox")){
				clearAndSendKeys(BuildingnoStreetHealthTextBox, policyInfoIntermidiaryEntity.getStringValueForField("BuildingnoStreetTextBo"));
			}
			
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigGstRegestrationIDDropDown")){
				click(GstRegestrationIDHealthDropDown);
				String registrationId=policyInfoIntermidiaryEntity.getStringValueForField("GstRegestrationIDDropDown");
				GstRegestrationIDRadioButton1=new MobileScreenElement(By.xpath("//android.widget.CheckedTextView[@text="+"'"+registrationId+"'"+"]"), "Dependency Type", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
				click(GstRegestrationIDRadioButton1);
				scrollDown();
			}

			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigGstIntextbox")){
				clearAndSendKeys(GstInHealthtextbox, policyInfoIntermidiaryEntity.getStringValueForField("GstIntextbox"));
			}
			
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigStateTextBox")){				
				clearAndSendKeys(StateHealthTextBox, policyInfoIntermidiaryEntity.getStringValueForField("State"));
				click(StateHealthname);
			}
			scrollDown();
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigpincodeTextBox")){
				click(PinCodeHealth3TExtBox);
				String pinCode= policyInfoIntermidiaryEntity.getStringValueForField("pin");
				PinNoHealthTextField=new MobileScreenElement(By.xpath("//android.view.View[@text="+"'"+pinCode+"'"+"]"),"Pincode Number", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
				clearAndSendKeys(PinCodeHealth3TExtBox, pinCode);		
				click(PinNoHealthTextField);
			}
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigCityTextBox")){
				clearAndSendKeys(CityHealthTextBox, policyInfoIntermidiaryEntity.getStringValueForField("CityTextBox"));
			}
			
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigMobileNumberTextBox")){
				click(MobileNoHealth3TExtField);
				clearAndSendKeys(MobileNoHealth3TExtField, policyInfoIntermidiaryEntity.getStringValueForField("MobileNumberTextBox"));
			}

			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigEmailIDTextBox")){
				clearAndSendKeys(EmailIDHealthTextBox, policyInfoIntermidiaryEntity.getStringValueForField("EmailIDTextBox"));
			}
			
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigPanNOTextBox")){
				clearAndSendKeys(PanNoHealthTextBox, policyInfoIntermidiaryEntity.getStringValueForField("PanNOTextBox"));
			}
		}


		else if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health3")))  {	
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigFirstNameTextBox")){
				clearAndSendKeys(FristNameHealthTextBox1, policyInfoIntermidiaryEntity.getStringValueForField("FirstNameTextBox"));
			}
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigMiddleNameTextBox")){
				//	clearAndSendKeys(MiddleNameHealthTextBox, policyInfoIntermidiaryEntity.getStringValueForField("MiddleNameTextBox"));
			}
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigLastNameTextBox")){
				clearAndSendKeys(LastNameHealthHelthTextBox1, policyInfoIntermidiaryEntity.getStringValueForField("lastNameTextBox"));
			}

			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigGenderMaleRadioButton")){
				click(GenderMaleHealthRadioButton);
			}
			try {
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigDateOfBirthTExtBox")){
				click(DateOfBirthHealthTExtBox);
				click(yeardropdown);
				TouchAction action=new TouchAction(driver);
				action.longPress(PointOption.point(170,247))
				.moveTo(PointOption.point(200,2423)).release().perform();
				
				TouchAction action1=new TouchAction(driver);
				action1.longPress(PointOption.point(170,247))
				.moveTo(PointOption.point(200,2423)).release().perform();
				click(yearvalue);
				click(dateOption);
				//	click(okButton);
			}
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigNationality")){
				click(nationalityButton);
				String Nationality= policyInfoIntermidiaryEntity.getStringValueForField("Nationality");
				nationalityButton1=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+Nationality+"'"+"]"), "Nationality", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
				click(nationalityButton1);
				click(okButton);
			}
			scrollToElementForward();
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigBuildingnoStreetTextBox")){
				scrollDown();
				clearAndSendKeys(BuildingnoStreetHealth3TextBox, policyInfoIntermidiaryEntity.getStringValueForField("BuildingnoStreetTextBo"));
				
			}

			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigGstRegestrationIDDropDown")){
				click(GstRegestrationIDDropDownHelth);
				String registrationId=policyInfoIntermidiaryEntity.getStringValueForField("GstRegestrationIDDropDown");
				GstRegestrationIDRadioButton1=new MobileScreenElement(By.xpath("//android.widget.CheckedTextView[@text="+"'"+registrationId+"'"+"]"), "Dependency Type", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
				click(GstRegestrationIDRadioButton1);
			}

			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigGstIntextbox")){
				clearAndSendKeys(GstInHealth3TextBox, policyInfoIntermidiaryEntity.getStringValueForField("GstIntextbox"));
				//scrollToElementForward();
			}
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigStateTextBox")){				
				clearAndSendKeys(StateHealth3TextBox, policyInfoIntermidiaryEntity.getStringValueForField("State"));
				click(StateHealthname);
			}
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigpincodeTextBox")){
				click(PinCodeHealth3TExtBox);
				String pinCode= policyInfoIntermidiaryEntity.getStringValueForField("pin");
				PinNoHealthTextField=new MobileScreenElement(By.xpath("//android.view.View[@text="+"'"+pinCode+"'"+"]"),"Pincode Number", false, WaitType.WAITFORELEMENTTOBEDISPLAYED, 10);
				clearAndSendKeys(PinCodeHealth3TExtBox, pinCode);		
				click(PinNoHealthTextField);
			}
			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigCityTextBox")){
				clearAndSendKeys(CityHealth3TextBox, policyInfoIntermidiaryEntity.getStringValueForField("CityTextBox"));
			}

			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigMobileNumberTextBox")){
				click(MobileNoHealth3TExtField);
				clearAndSendKeys(MobileNoHealth3TExtField, policyInfoIntermidiaryEntity.getStringValueForField("MobileNumberTextBox"));
			}

			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigEmailIDTextBox")){
				clearAndSendKeys(EmailIDHealthTextBox, policyInfoIntermidiaryEntity.getStringValueForField("EmailIDTextBox"));
			}

			if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigPanNOTextBox")){
				clearAndSendKeys(PanNoHealthTextBox, policyInfoIntermidiaryEntity.getStringValueForField("PanNOTextBox"));
			}

		}
	}

	public void fetchQuoteNumber(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity) throws InterruptedException {
		if(policyInfoIntermidiaryEntity.getBooleanValueForField("Configpartycode")){
			policyInfoIntermidiaryEntity.setStringValueForField("QuoteNo", fetchValueFromFields(AlertText));
		}
	}


	public void clickOnCreateButton(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity,CustomAssert assertReference ) throws InterruptedException{
		if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigCreateButton")){
			scrollDown();
			click(CreateButton);
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Motor"))||policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("HomeAndAccident")
					||policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health")||policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health3"))   {	
				click(okButton);
				try {
					click(continueButton);
				}
				catch(Exception e) {
					System.out.println(e.getMessage());
				}
			}
		}
		if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigSaveAndCalculatePremium")){
			click(saveAndCalculateButton);
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health")))  {
				click(saveAndRecalculateButton);
			}
		}
	}


	public void clickNextPageButton(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity,CustomAssert  assertReference  ){
		if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigNextButton")){
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health"))) {
				click(continueButton);
			}
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health3"))) {
				click(NextButton);
			}
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("HomeAndAccident"))) {
				click(NextbuttonHm);	
			}
		}
	}



	public void clickNextPageButtonHM(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity,CustomAssert  assertReference  ){
		if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigNextButtonHM")){
			scrollDown();
			if((policyInfoIntermidiaryEntity.getStringValueForField("Product").equalsIgnoreCase("New India Cancer Guard Policy"))||(policyInfoIntermidiaryEntity.getStringValueForField("Product").equalsIgnoreCase("New India Premier Mediclaim Policy"))) {
				click(NextbuttonHm);
			}
			try {
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health"))) {
				click(continueButton);
			}
			}
			catch(Exception e) {
				
			}
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("HomeAndAccident"))) {
				click(NextbuttonHm);	
			}
		}

	}
	public void clickOnProceedOption(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity,CustomAssert  assertReference  ) throws InterruptedException{
		if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProceed")){
				//click(proceedButton);

			TouchAction action = new TouchAction(driver);
			action.press(PointOption.point(1029,1198)).release().perform();
			
		}
		if (policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigHEalthOk")){

			TouchAction action1 = new TouchAction(driver);
			action1.press(PointOption.point(1063 ,1663)).release().perform();

		}
	}

	public void clickEditButton(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity,CustomAssert  assertReference  ){
		if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigEdit")){
			click(editButton);
		}
	}
	public void fillRelationDetails(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity,CustomAssert assertReference ) throws InterruptedException{
		if(policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("add")||policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("edit")){
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health"))) {
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigRelations")){
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigAgentRequired")){
						click(yesRadioButton);
					}
					if (policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigAgentNotRequired")) {
						click(noRadioButton);
					}
					click(saveAndRecalculateButton);
				}
			}
		}
	}

	public void fillHealth3RelationDetails(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity,CustomAssert assertReference ) throws InterruptedException{
		if(policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("add")||policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("edit")){
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health33"))) {
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigRelations")){
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigAgentRequired")){
						click(yesRadioButton);
					}
					if (policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigAgentNotRequired")) {
						click(noRadioButton);
					}
					click(SaveAndRECalculatePrimiumHelth3Button);
				}
			}
		}
	}
	public void fillProposerDetails(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity,CustomAssert assertReference ) throws InterruptedException{
		if(policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("add")||policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("edit")){
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health"))) {
				click(proposerButton);
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposer")){
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposerName")){
						clearAndSendKeys(proposerNameTextfield, policyInfoIntermidiaryEntity.getStringValueForField("ProposerName"));
					}
					if (policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposerOccupation")) {
						click(proposerOccupationDropDown);
						String proposerOccupation=policyInfoIntermidiaryEntity.getStringValueForField("ProposerOccupation");
						proposerOccupationRadioButton1=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+proposerOccupation+"'"+"]"), "Occupation", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
						click(proposerOccupationRadioButton1);
						click(okButton);
						//selectValueFromList(proposerOccupationDropDown, healthAddDetailEntity.getStringValueForField("ProposerOccupation"));
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposerHeight")){
						clearAndSendKeys(proposerHeightTextfield, policyInfoIntermidiaryEntity.getStringValueForField("ProposerHeight"));
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposerWeight")){
						clearAndSendKeys(proposerWeightTextfield, policyInfoIntermidiaryEntity.getStringValueForField("ProposerWeight"));
					}
					scrollDown();
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("configPreExistingDis")){
						clearAndSendKeys(preExistingDisTextField, policyInfoIntermidiaryEntity.getStringValueForField("PreExistingDis"));
					}
					if (policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposerNatureOfId")) {
						click(proposerNatureOfIdDropDown);
						String proposerNatureOfId=policyInfoIntermidiaryEntity.getStringValueForField("ProposerNatureOfId");
						proposerNatureOfIdRadioButton1=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+proposerNatureOfId+"'"+"]"), "Nature Of Id", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
						click(proposerNatureOfIdRadioButton1);
						click(okButton);
						//selectValueFromList(proposerOccupationDropDown, healthAddDetailEntity.getStringValueForField("ProposerOccupation"));
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigIDDocNo")){
						clearAndSendKeys(IDDocNoTextfield, policyInfoIntermidiaryEntity.getStringValueForField("IDDocNo"));
					}
					scrollDown();
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposerId")){
						clearAndSendKeys(proposerIdTextfield, policyInfoIntermidiaryEntity.getStringValueForField("ProposerId"));
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("configHealthPolicyPast")){
						click(noRadioButton);
					}
					try {
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("configBladderhabitsRadioButton")){
						
						click(bladderhabitsRadioButton);
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("configSoreRadioButton")){
						click(soreRadioButton);
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("configunusualBleedingRadioButton")){
						click(unusualBleedingRadioButton);
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("configlumpInBreastRadioButton")){
						click(lumpInBreastRadioButton);
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("configpersistentIndigestionRadioButton")){
						click(persistentIndigestionRadioButton);
					}
					scrollDown();
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("configwartOrMoleRadioButton")){
						click(wartOrMoleRadioButton);
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("configcoughOrHoarsenessRadioButton")){
						click(coughOrHoarsenessRadioButton);
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("configabnormalWeightLossRadioButton")){
						click(abnormalWeightLossRadioButton);
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("configconfigchemotherapyRadiotherapyRadioButton")){
						click(chemotherapyRadiotherapyRadioButton);
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("configparentsSiblingsCancerRadioButton")){
						click(parentsSiblingsCancerRadioButton);
					}
					}
					catch(Exception e)
					{
						
					}
				}
			}
		}
	}
	//start
	public void fillProposerHEalth3Details(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity,CustomAssert assertReference ) throws InterruptedException{
		if(policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("add")||policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("edit")){
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health3"))) {
				click(proposerButton);
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposer")){
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposerName")){
						clearAndSendKeys(proposerNameTextfield, policyInfoIntermidiaryEntity.getStringValueForField("ProposerName"));
					}
					if (policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposerOccupation")) {
						click(proposerOccupationDropDown);
						String proposerOccupation=policyInfoIntermidiaryEntity.getStringValueForField("ProposerOccupation");
						proposerOccupationRadioButton1=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+proposerOccupation+"'"+"]"), "Occupation", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
						click(proposerOccupationRadioButton1);
						click(okButton);
						//selectValueFromList(proposerOccupationDropDown, healthAddDetailEntity.getStringValueForField("ProposerOccupation"));
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposerHeight")){
						clearAndSendKeys(proposerHeightTextfield, policyInfoIntermidiaryEntity.getStringValueForField("ProposerHeight"));
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposerWeight")){
						clearAndSendKeys(proposerWeightTextfield, policyInfoIntermidiaryEntity.getStringValueForField("ProposerWeight"));
					}
					if (policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposerNatureOfId")) {
						click(proposerNatureOfIdDropDown);
						String proposerNatureOfId=policyInfoIntermidiaryEntity.getStringValueForField("ProposerNatureOfId");
						proposerNatureOfIdRadioButton1=new MobileScreenElement(By.xpath("//android.widget.CheckedTextView[@text="+"'"+proposerNatureOfId+"'"+"]"), "Nature Of Id", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
						click(proposerNatureOfIdRadioButton1);
						//selectValueFromList(proposerOccupationDropDown, healthAddDetailEntity.getStringValueForField("ProposerOccupation"));
					}
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposerId")){
						clearAndSendKeys(proposerIdTextfield, policyInfoIntermidiaryEntity.getStringValueForField("ProposerId"));
					}

				}
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigSpouse")){
					/*if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigSpouseName")){
						clearAndSendKeys(spouseNameTextfield, policyInfoIntermidiaryEntity.getStringValueForField("SpouseName"));
					}*/
				}
			}
		}
	}


	public void fillSpouseHEalthDetails(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity,CustomAssert assertReference ) throws InterruptedException{
		if(policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("add")||policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("edit")){
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health"))) {
				if(!((policyInfoIntermidiaryEntity.getStringValueForField("Product").equalsIgnoreCase("New India Cancer Guard Policy"))||(policyInfoIntermidiaryEntity.getStringValueForField("Product").equalsIgnoreCase("New India Premier Mediclaim Policy")))) {
				click(spouseButton);
				scrollDown();
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigSpouseName")){
					clearAndSendKeys(SpouseNameTextfield, policyInfoIntermidiaryEntity.getStringValueForField("ProposerName"));
				}
				if (policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigProposerOccupation")) {
					click(proposerOccupationDropDown);
					String proposerOccupation=policyInfoIntermidiaryEntity.getStringValueForField("ProposerOccupation");
					proposerOccupationRadioButton1=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+proposerOccupation+"'"+"]"), "Occupation", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
					click(proposerOccupationRadioButton1);
					click(okButton);
					
					scrollToElementForward();
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigNationality")){
						click(nationalityButton);
						String Nationality= policyInfoIntermidiaryEntity.getStringValueForField("Nationality");
						nationalityButton1=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+Nationality+"'"+"]"), "Nationality", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
						click(nationalityButton1);
						click(okButton);
					}
					try {
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigFemaleMaleRadioButton")){
						click(GenderFemaleHealthRadioButton);
					}	
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("configHealthPolicyPast")){
						click(noRadioButton1);
					}
					}
					catch(Exception e) {
						
					}
				}
			}
		}
	}
	}
	public void fillNomineeDetails(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity,CustomAssert assertReference ) throws InterruptedException{
		if(policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("add")||policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("edit")){
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health"))) {
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigNomineeName")){
					clearAndSendKeys(nomineeNameTextfield, policyInfoIntermidiaryEntity.getStringValueForField("NomineeName"));
				}
				if (policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigNomineeOccupation")) {
					click(nomineeRelationDropDown);
					String nomineeRelation=policyInfoIntermidiaryEntity.getStringValueForField("NomineeOccupation");
					nomineeRelationRadioButton1=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+nomineeRelation+"'"+"]"), "Relation", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
					click(nomineeRelationRadioButton1);
					click(okButton);
					//selectValueFromList(proposerOccupationDropDown, healthAddDetailEntity.getStringValueForField("ProposerOccupation"));
				}
				scrollDown();
				try {
					if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigDateOfBirthTExtBox")){
						click(DateOfBirthHealthTExtBox);
						click(yeardropdown);
						TouchAction action=new TouchAction(driver);
						action.longPress(PointOption.point(170,247))
						.moveTo(PointOption.point(200,2423)).release().perform();
						
						TouchAction action1=new TouchAction(driver);
						action1.longPress(PointOption.point(170,247))
						.moveTo(PointOption.point(200,2423)).release().perform();
						click(yearvalue);
						click(dateOption);
						//	click(okButton);
					}
				}
				catch(Exception e) {
					
				}
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigAppointeeName")){
					clearAndSendKeys(appointeeNameTextfield, policyInfoIntermidiaryEntity.getStringValueForField("AppointeeName"));
				}
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("configRelationAppointee")){
					clearAndSendKeys(relationAppointeeTextfield, policyInfoIntermidiaryEntity.getStringValueForField("RelationAppointee"));
				}
				scrollDown();
				click(saveAndRecalculateButton);
			}
		}
	}



	public void fillNomineeHealth3Details(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity,CustomAssert assertReference ) throws InterruptedException{
		if(policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("add")||policyInfoIntermidiaryEntity.getAction().equalsIgnoreCase("edit")){
			if((policyInfoIntermidiaryEntity.getStringValueForField("LOB").equalsIgnoreCase("Health3"))) {
				if(policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigNomineeName")){
					clearAndSendKeys(nomineeNameTextfield, policyInfoIntermidiaryEntity.getStringValueForField("NomineeName"));
				}
				if (policyInfoIntermidiaryEntity.getBooleanValueForField("ConfigNomineeOccupation")) {
					click(RelationWithNomineeDropDown);
					String nomineeRelation=policyInfoIntermidiaryEntity.getStringValueForField("NomineeOccupation");
					nomineeRelationRadioButton1=new MobileScreenElement(By.xpath("//android.widget.RadioButton[@text="+"'"+nomineeRelation+"'"+"]"), "Relation", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);
					click(nomineeRelationRadioButton1);
					click(okButton);
					//selectValueFromList(proposerOccupationDropDown, healthAddDetailEntity.getStringValueForField("ProposerOccupation"));
				}
				click(saveAndRecalculateButton);
			}
		}
	}


	public void fillAndSubmitHolderInformationIntermidiaryEntity(PolicyInfoIntermidiaryEntity policyInfoIntermidiaryEntity,CustomAssert assertReference ) throws Exception {
		if(isConfigTrue(policyInfoIntermidiaryEntity.getConfigExecute())){		
			{
				fillAndsubmitpolicyholderInformation(policyInfoIntermidiaryEntity,assertReference);
				clickOnCreateButton(policyInfoIntermidiaryEntity, assertReference);
				fetchQuoteNumber(policyInfoIntermidiaryEntity);
				clickOnProceedOption(policyInfoIntermidiaryEntity, assertReference);
				clickEditButton(policyInfoIntermidiaryEntity, assertReference);
				fillProposerDetails(policyInfoIntermidiaryEntity, assertReference);
				fillProposerHEalth3Details(policyInfoIntermidiaryEntity, assertReference);
				clickNextPageButton(policyInfoIntermidiaryEntity,assertReference);
				fillSpouseHEalthDetails(policyInfoIntermidiaryEntity,assertReference);
				clickNextPageButtonHM(policyInfoIntermidiaryEntity,assertReference);
				fillNomineeHealth3Details(policyInfoIntermidiaryEntity, assertReference);
				fillNomineeDetails(policyInfoIntermidiaryEntity, assertReference);
				fillRelationDetails(policyInfoIntermidiaryEntity, assertReference);
				fillHealth3RelationDetails(policyInfoIntermidiaryEntity, assertReference);
			}         
		}
	}
}