package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class BuyNowEntermidiaryEntity extends GenericEntity {

	public BuyNowEntermidiaryEntity() {
		super("BuyNowEntermidiaryEntity");
		// TODO Auto-generated constructor stub
	}

}
