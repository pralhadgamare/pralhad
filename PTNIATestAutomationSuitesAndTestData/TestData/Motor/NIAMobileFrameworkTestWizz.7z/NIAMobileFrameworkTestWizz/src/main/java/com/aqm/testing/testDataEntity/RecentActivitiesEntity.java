package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class RecentActivitiesEntity extends GenericEntity {

	public RecentActivitiesEntity() {
		super("RecentActivitiesEntity");
		// TODO Auto-generated constructor stub
	}

}
