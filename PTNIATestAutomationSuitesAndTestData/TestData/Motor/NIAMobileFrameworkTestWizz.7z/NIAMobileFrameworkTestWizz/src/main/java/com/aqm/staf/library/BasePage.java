package com.aqm.staf.library;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import com.aqm.framework.constant.WaitType;
import com.aqm.framework.core.MobileScreen;
import com.aqm.framework.core.MobileScreenElement;
import com.aqm.framework.exceptions.ScriptExecutionException;

import io.appium.java_client.android.AndroidDriver;

public class BasePage extends MobileScreen{

	private MobileScreenElement wedgetList;

	public BasePage(AndroidDriver driver, String pageName) {
		super(driver, pageName);
		wedgetList=new MobileScreenElement(By.xpath("//li[@id='widgetListLi']//a[@class='dropdown-toggle']"), "Widget List", false, WaitType.WAITFORELEMENTTOBECLICKABLE, 10);}
	
	protected void navigateToMarketWatch() {
		click(wedgetList);
	}
	
	
	public static String dateGenerator(String dateToBeAdded){
		String exp=null;
		String getPortalFormatDate=null;
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		cal.setTime(date);
		if(dateToBeAdded.contains("oldDate:")) {
			String[]day=dateToBeAdded.split(":");
			String daytoBeadded=day[1];
			int dayToBeadded=Integer.parseInt(daytoBeadded);	
			cal.add(Calendar.DATE, -dayToBeadded); // add 10 days
			date = cal.getTime();
			exp= dateFormat.format(date).toString();
			getPortalFormatDate=exp.replace("/","");
		}
		else if(dateToBeAdded.contains("futureDate:")) {
			String[]day=dateToBeAdded.split(":");
			String daytoBeadded=day[1];
			int dayToBeadded=Integer.parseInt(daytoBeadded);	
			cal.add(Calendar.DATE,dayToBeadded); // add 10 days
			date = cal.getTime();
			exp= dateFormat.format(date).toString();
			getPortalFormatDate=exp.replace("/","");
		}
		else if(dateToBeAdded.contains("now")) {
			exp= dateFormat.format(date).toString();
			getPortalFormatDate=exp.replace("/","");
		}
		return getPortalFormatDate;
		
		/*for calling use
		  String mydate;
		  mydate = dateGenerator(Date);
		  clearAndSendKeys(dateTextField,mydate);
		*/
		
	}
	
	protected void switchToTab(){
		try{
			ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		   // driver.switchTo().window(tabs2.get(0));
		    //driver.close();
		    driver.switchTo().window(tabs2.get(1));
		}catch(Exception e){
			throw new ScriptExecutionException ("Failed to search Criteria: ", e);
		}
	}
	protected void switchBackToTab(){
		try{
			ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		    driver.close();
		    driver.switchTo().window(tabs2.get(0));
		}catch(Exception e){
			throw new ScriptExecutionException ("Failed to search Criteria: ", e);
		}
	}
	
	
}
