package com.aqm.staf.library;

import java.util.Properties;

import org.openqa.selenium.WebDriver;

import com.aqm.framework.core.CustomAssert;
import com.aqm.framework.core.FrameworkServices;
import com.aqm.framework.core.StepWiseExecution;
import com.aqm.framework.core.TestData;
import com.aqm.framework.entities.ExecutionTestSteps;
import com.aqm.framework.entities.TestScenario;
import com.aqm.staf.library.PageKeyWord.KeywordHelper;

import io.appium.java_client.AppiumDriver;



public class FunctionalKeywords extends KeywordHelper implements StepWiseExecution

{
	public static Properties prop;
	private  String stepGroup;
	private KeywordHelper keyWordHelper;

	public void executeStep(TestScenario testScenario, ExecutionTestSteps executionTestStep, TestData testData, WebDriver driverWeb, CustomAssert assertReference) throws Exception {
		AppiumDriver driver = (AppiumDriver)driverWeb;
		String keyword = executionTestStep.getExecutionTestStepMasterAutomationScriptStepKeyword();
		int stepNumber= executionTestStep.getExecutionTestStepMasterAutomationScriptStepExecutionSequence();
		stepGroup = executionTestStep.getExecutionTestStepMasterAutomationScriptStepStepGroup();
		FrameworkServices.logMessage("<B><u>StepNumber-</u>"+stepNumber+"<i><Font Color = /'#00008B/'> Executing :"+keyword+" </Font></i></B>");
		keyWordHelper = new KeywordHelper();
		int skipStepsInExecution= Integer.parseInt(FrameworkServices.getConfigurationPropertie().getProperty("skipSteps"));
		System.out.println("Done");
		if (stepNumber>=skipStepsInExecution){
			switch (keyword) {

			/************************************NIA Mobile Automation************************************/
			case "CreateLogin":
				CreateLoginNIAMobileApp(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditLogin":
				EditLoginNIAMobileApp(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "VerifyLogin":
				VerifyLoginNIAMobileApp(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "CreateHomepage":
				CreateHomePage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditHomepage":
				EditHomePage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "VerifyHomepage":
				VerifyHomePage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;	
			case "CreateBuyNowIntermediary":
				CreateBuyNowInterPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditBuyNowIntermediary":
				EditBuyNowInterPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "VerifyBuyNowIntermediary":
				VerifyBuyNowInterPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;	
			case "CreatePremiumCalulatorHealth":
				CreatePremiumCalculatorPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditPremiumCalulatorHealth":
				EditPremiumCalculatorPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "VerifyPremiumCalulatorHealth":
				VerifyPremiumCalculatorPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "CreateTwoWheelerBasicPremium":
				CreateTwoWheelerBasicPremium(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditTwoWheelerBasicPremium":
				EditTwoWheelerBasicPremium(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "VerifyTwoWheelerBasicPremium":
				VerifyTwoWheelerBasicPremium(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "CreateTwoWheelerBuyInsurance":
				CreateTwoWheelerBuyInsurance(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "EditTwoWheelerBuyInsurance":
				EditTwoWheelerBuyInsurance(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "VerifyTwoWheelerBuyInsurance":
				VerifyTwoWheelerBuyInsurance(testData, executionTestStep, assertReference, driver, stepGroup);	
				break;

			case "CreateBuyNow":			
				CreateBuyNowPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "EditBuyNow":
				EditBuyNowPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "VerifyBuyNow":
				VerifyBuyNowPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

				/*case "CreateNewIndiaTopUpMediclaim":			
				CreateBuyNowPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditNewIndiaTopUpMediclaim":
				EditBuyNowPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "VerifyNewIndiaTopUpMediclaim":
				VerifyBuyNowPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;*/

				//PrvateCar

			case "CreatePrivateCar":			
				CreatePrivateCarPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditPrivateCar":
				EditPrivateCarPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "VerifyPrivateCar":
				VerifyPrivateCarPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "CreateNewIndiaTopUpMediclaim":			
				CreateNewIndiaTopUpMediclaimPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditNewIndiaTopUpMediclaim":
				EditNewIndiaTopUpMediclaimPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "VerifyNewIndiaTopUpMediclaim":
				VerifyNewIndiaTopUpMediclaimPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "CreateTopUpHealthAdditionalDeatils":			
				CreateTopUpHealthAdditionalDeatils(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditTopUpHealthAdditionalDeatils":
				EditTopUpHealthAdditionalDeatils(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "VerifyTopUpHealthAdditionalDeatils":
				VerifyTopUpHealthAdditionalDeatils(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "CreatePremiumSummary":			
				CreatePremiumSummaryPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditPremiumSummary":
				EditPremiumSummaryPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "VerifyPremiumSummary":
				VerifyPremiumSummaryPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "CreatePersonalAccidentDet":			
				CreatePersonalAccidentDet(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditPersonalAccidentDet":
				EditPersonalAccidentDet(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "VerifyPersonalAccidentDet":
				VerifyPersonalAccidentDet(testData, executionTestStep, assertReference, driver, stepGroup);
				break;


			case "CreateAdditionalDetails":			
				CreateAdditionalDetailsPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditAdditionalDetails":
				CreateAdditionalDetailsPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "VerifyAdditionalDetails":
				CreateAdditionalDetailsPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "CreateSummary":			
				CreateSummaryPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditSummary":
				EditSummaryPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "VerifySummary":
				VerifySummaryPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "CreateDetailedTravelDetails":			
				CreateDetailedTravelDetailsPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditDetailedTravelDetails":
				EditDetailedTravelDetailsPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "VerifyDetailedTravelDetails":
				VerifyDetailedTravelDetailsPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "CreateHomeIntermediaryDetails":
				CreateHomeIntermediaryPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "EditHomeIntermediaryPage":
				CreateHomeIntermediaryPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "VerifyHomeIntermediaryDetails":
				VerifyHomeIntermediaryPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
				
			case "CreateRecentActivities":			
				CreateRecentActivitiesPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "EditRecentActivities":
				EditRecentActivitiesPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;
			case "VerifyRecentActivities":
				VerifyRecentActivitiesPage(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

				//intermidiary

			case "CreateBuyNowIntermidary":
				CreateBuyNowIntermidary(testData,executionTestStep,assertReference,driver,stepGroup);
				break;

			case "EditBuyNowIntermidary":
				EditBuyNowIntermidary(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "verifyBuyNowIntermidary":
				verifyBuyNowIntermidary(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

				//TwoWheelerDeils

			case "CreateTwoWheelerDetails":
				createTwoWheelerDetails(testData,executionTestStep,assertReference,driver,stepGroup);
				break;

			case "EditTwoWheelerDetails":
				editTwoWheelerDetails(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "VerifyTwoWheelerDetails":
				verifyTwoWheelerDetails(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

				//inter

			case "CreateadditionalDetailsPageForIntermidiaryDetails":
				CreateadditionalDetailsPageForIntermidiary(testData,executionTestStep,assertReference,driver,stepGroup);
				break;

			case "EditadditionalDetailsPageForIntermidiaryDetails":
				EditadditionalDetailsPageForIntermidiary(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "VerifyadditionalDetailsPageForIntermidiaryDetails":
				verifyadditionalDetailsPageForIntermidiary(testData, executionTestStep, assertReference, driver, stepGroup);
				break;


			case "CreatePolicyHolderInformationIntermidiaryDetails":
				createPolicyHolderInformationIntermidiary(testData,executionTestStep,assertReference,driver,stepGroup);
				break;

			case "EditPolicyHolderInformationIntermidiaryDetails":
				editPolicyHolderInformationIntermidiary(testData,executionTestStep,assertReference,driver,stepGroup);
				break;

			case "VerifyPolicyHolderInformationIntermidiaryDetails":
				verifyPolicyHolderInformationIntermidiary(testData, executionTestStep, assertReference, driver, stepGroup);
				break;




			case "CreateAddressFinencierDetailDetails":
				CreateAddressFinencierDetail(testData,executionTestStep,assertReference,driver,stepGroup);
				break;

			case "EditAddressFinencierDetailDetails":
				editAddressFinencierDetail(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "VerifyAddressFinencierDetailDetails":
				verifyAddressFinencierDetail(testData, executionTestStep, assertReference, driver, stepGroup);
				break;



			case "CreateSummaryIntermidiateDetail":
				CreateSummaryIntermidiateDetail(testData,executionTestStep,assertReference,driver,stepGroup);
				break;

			case "EditSummaryIntermidiateDetail":
				EditSummaryIntermidiateDetail(testData, executionTestStep, assertReference, driver, stepGroup);
				break;

			case "VerifySummaryIntermidiateDetail":
				VerifySummaryIntermidiateDetail(testData, executionTestStep, assertReference, driver, stepGroup);
				break;



			case "CreateCollectionDetail":
				CreateCollectionDetail(testData,executionTestStep,assertReference,driver,stepGroup);
				break;


			case "EditCollectionDetail":
				editCollectionDetail(testData,executionTestStep,assertReference,driver,stepGroup);
				break;


			case "VerifyCollectionDetaill":
				verifyCollectionDetail(testData,executionTestStep,assertReference,driver,stepGroup);
				break;



				//By Paresh

			case "CreateTWdetailsIntmy":
				CreateTWdetailsIntmy(testData,executionTestStep,assertReference,driver,stepGroup);
				break;


			case "EditTWdetailsIntmy":
				EditTWdetailsIntmy(testData,executionTestStep,assertReference,driver,stepGroup);
				break;


			case "VerifyTWdetailsIntmy":
				VerifyTWdetailsIntmy(testData,executionTestStep,assertReference,driver,stepGroup);
				break;	


				//

			case "CreateTWBasicPremiumIntmy":
				CreateTWBasicPremiumIntmy(testData,executionTestStep,assertReference,driver,stepGroup);
				break;


			case "EditTWBasicPremiumIntmy":
				EditTWBasicPremiumIntmy(testData,executionTestStep,assertReference,driver,stepGroup);
				break;


			case "VerifyTWBasicPremiumIntmy":
				VerifyTWBasicPremiumIntmy(testData,executionTestStep,assertReference,driver,stepGroup);
				break;	


				//
			case "CreateInsuredDetails":
				CreateInsuredDetailsPage(testData,executionTestStep,assertReference,driver,stepGroup);
				break;


			case "EditInsuredDetails":
				EditInsuredDetailsPage(testData,executionTestStep,assertReference,driver,stepGroup);
				break;


			case "VerifyInsuredDetails":
				VerifyInsuredDetailsPage(testData,executionTestStep,assertReference,driver,stepGroup);
				break;	

				//
			case "CreateVehicleDetailsIntermidiary":
				CreateVehicleDetailsIntermidiary(testData,executionTestStep,assertReference,driver,stepGroup);
				break;


			case "EditVehicleDetailsIntermidiary":
				EditVehicleDetailsIntermidiary(testData,executionTestStep,assertReference,driver,stepGroup);
				break;


			case "VerifyVehicleDetailsIntermidiary":
				VerifyVehicleDetailsIntermidiary(testData,executionTestStep,assertReference,driver,stepGroup);
				break;	


				//
			case "CreateQuickRenewPolicy":
				createQuickRenewPolicy(testData,executionTestStep,assertReference,driver,stepGroup);
				break;


			case "EditQuickRenewPolicy":
				editQuickRenewPolicy(testData,executionTestStep,assertReference,driver,stepGroup);
				break;


			case "VerifyQuickRenewPolicy":
				verifyQuickRenewPolicy(testData,executionTestStep,assertReference,driver,stepGroup);
				break;	
			
			default:System.out.println("Add Your keywords here");
			}
		}
	}	
}
