package com.aqm.staf.library.PageKeyWord;

import java.util.List;
import com.aqm.framework.entities.ExecutionTestSteps;
import com.aqm.staf.library.pages.common.AdditionalDetailsMotorPage;
import com.aqm.staf.library.pages.common.AdditionalDetailsPageForIntermidiary;
import com.aqm.staf.library.pages.common.AddressFinancierDetailPage;
import com.aqm.staf.library.pages.common.BuyNowIntermediaryPage;
import com.aqm.staf.library.pages.common.BuyNowPage;
import com.aqm.staf.library.pages.common.CollectionIntemidiaryPage;
import com.aqm.staf.library.pages.common.DetailedTravelDetailsPage;
import com.aqm.staf.library.pages.common.GrihaSuvidhaBuyNowPages;
import com.aqm.staf.library.pages.common.HomeIntermediaryPage;
import com.aqm.staf.library.pages.common.HomePage;
import com.aqm.staf.library.pages.common.NewIndiaTopUpMediclaimPage;
import com.aqm.staf.library.pages.common.NiaLoginPage;
import com.aqm.staf.library.pages.common.PersonalAccidentDet;
import com.aqm.staf.library.pages.common.PolicyHolderInformationIntermidiarypage;
import com.aqm.staf.library.pages.common.PremiumCalHealthPage;
import com.aqm.staf.library.pages.common.PremiumSummaryPage;
import com.aqm.staf.library.pages.common.PrivateCarPage;
import com.aqm.staf.library.pages.common.QuickPayRenewalPolicyDetailsPage;
import com.aqm.staf.library.pages.common.RecentActivitiesPage;
import com.aqm.staf.library.pages.common.SummaryPage;
import com.aqm.staf.library.pages.common.SummaryPymentDetailInterPage;
import com.aqm.staf.library.pages.common.TWBasicPremiumIntmdyPage;
import com.aqm.staf.library.pages.common.TWDetailsIntmdryPage;
import com.aqm.staf.library.pages.common.TWInsuredDetailsIntmyPage;
import com.aqm.staf.library.pages.common.TopUpHealthAdditionalDeatils;
import com.aqm.staf.library.pages.common.TwoWheelerBasicPremiumPage;
import com.aqm.staf.library.pages.common.TwoWheelerBuyInsurancePage;
import com.aqm.staf.library.pages.common.TwoWheelerDetailsPage;
import com.aqm.staf.library.pages.common.VehicleDetailsIntermidiaryPage;
import com.aqm.testing.testDataEntity.AdditionalDetailsMotorEntity;
import com.aqm.testing.testDataEntity.AddressFinancierDetailEntity;
import com.aqm.testing.testDataEntity.AdtionalDetalsInterEntity;
import com.aqm.testing.testDataEntity.BuyNowEntermidiaryEntity;
import com.aqm.testing.testDataEntity.BuyNowEntity;
import com.aqm.testing.testDataEntity.BuyNowInterEntity;
import com.aqm.testing.testDataEntity.CollectionIntemidiaryEntity;
import com.aqm.testing.testDataEntity.DetailedTravelEntity;
import com.aqm.testing.testDataEntity.HealthAddDetailEntity;
import com.aqm.testing.testDataEntity.HomeIntermediaryEntity;
import com.aqm.testing.testDataEntity.HomepageEntity;
import com.aqm.testing.testDataEntity.LoginEntity;
import com.aqm.testing.testDataEntity.PersonalAccidentDetEntity;
import com.aqm.testing.testDataEntity.PolicyInfoIntermidiaryEntity;
import com.aqm.testing.testDataEntity.PremiumCalEntity;
import com.aqm.testing.testDataEntity.PremiumSummaryEntity;
import com.aqm.testing.testDataEntity.PrivateCarEntity;
import com.aqm.testing.testDataEntity.QuickRenewPolicyEntity;
import com.aqm.testing.testDataEntity.RecentActivitiesEntity;
import com.aqm.testing.testDataEntity.SummaryIntermidiarEntity;
import com.aqm.testing.testDataEntity.SummaryPageEntity;
import com.aqm.testing.testDataEntity.TWBasicPremiumIntmyEntity;
import com.aqm.testing.testDataEntity.TWInsuredDetailsIntmyEntity;
import com.aqm.testing.testDataEntity.TWdetailsIntmyEntity;
import com.aqm.testing.testDataEntity.TopUpMediEntity;
import com.aqm.testing.testDataEntity.TwoWheelerBasicPremiumEntity;
import com.aqm.testing.testDataEntity.TwoWheelerBuyInsuranceEntity;
import com.aqm.testing.testDataEntity.TwoWheelerDetailsEntity;
import com.aqm.testing.testDataEntity.VehicleDetailsIntmyEntity;

import io.appium.java_client.AppiumDriver;

import com.aqm.framework.core.TestData;
import com.aqm.framework.core.CustomAssert;
import com.aqm.framework.core.GenericEntity;

public class KeywordHelper{
	/*public void BuyandSellSearchPageHelper(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,WebDriver driver,String stepGroup) throws InterruptedException{
		List<BuyandSellEntity>buyandSelllist=testData.getData().get(BuyandSellEntity.class);
		for(BuyandSellEntity buyandSellData:buyandSelllist){
			if(buyandSellData.getAction().equalsIgnoreCase("add")&&buyandSellData.getStepGroup().equalsIgnoreCase(stepGroup)){
				BuyandSellSearchPage buyandSellSearchPage=new BuyandSellSearchPage(driver, "Home Page");
				buyandSellSearchPage.fillandSubmitBuyandSellDetail(buyandSellData, assertReference);
			}	
		}
	}*/

	//
	public void createTwoWheelerDetails(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup) throws InterruptedException {
		List<TwoWheelerDetailsEntity> twoWheelerDetailsEntity = testData.getData().get(TwoWheelerDetailsEntity.class);
		for (GenericEntity twoWheelerDetailsEntity_data : twoWheelerDetailsEntity) {
			if (twoWheelerDetailsEntity_data.getAction().equalsIgnoreCase("add") && twoWheelerDetailsEntity_data.getStepGroup().equalsIgnoreCase(stepGroup)) {
				TwoWheelerDetailsPage twoWheelerDetailsPage = new TwoWheelerDetailsPage(driver, "Two Wheeler Deatils");
				twoWheelerDetailsPage.fillAndSubmitTwoWheelerDetails((TwoWheelerDetailsEntity) twoWheelerDetailsEntity_data, assertReference, stepGroup);
				//setEditPaymentDependency((PremiumSummaryEntity) twoWheelerDetailsEntity_data, testData);
			}
		}
	}
	public void editTwoWheelerDetails(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup) throws InterruptedException {
		List<TwoWheelerDetailsEntity> twoWheelerDetailsEntity = testData.getData().get(TwoWheelerDetailsEntity.class);
		for (GenericEntity twoWheelerDetailsEntity_data : twoWheelerDetailsEntity) {
			if (twoWheelerDetailsEntity_data.getAction().equalsIgnoreCase("edit") && twoWheelerDetailsEntity_data.getStepGroup().equalsIgnoreCase(stepGroup)) {
				TwoWheelerDetailsPage twoWheelerDetailsPage = new TwoWheelerDetailsPage(driver, "Two Wheeler Deatils");
				twoWheelerDetailsPage.fillAndSubmitTwoWheelerDetails((TwoWheelerDetailsEntity) twoWheelerDetailsEntity_data, assertReference, stepGroup);
			}
		}
	}
	public void verifyTwoWheelerDetails(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup) throws InterruptedException {
		List<TwoWheelerDetailsEntity> twoWheelerDetailsEntity = testData.getData().get(TwoWheelerDetailsEntity.class);
		for (GenericEntity twoWheelerDetailsEntity_data : twoWheelerDetailsEntity) {
			if (twoWheelerDetailsEntity_data.getAction().equalsIgnoreCase("verify") && twoWheelerDetailsEntity_data.getStepGroup().equalsIgnoreCase(stepGroup)) {
				TwoWheelerDetailsPage twoWheelerDetailsPage = new TwoWheelerDetailsPage(driver, "Two Wheeler Deatils");
				twoWheelerDetailsPage.fillAndSubmitTwoWheelerDetails((TwoWheelerDetailsEntity) twoWheelerDetailsEntity_data, assertReference, stepGroup);
			}
		}
	}
	
	public void CreateLoginNIAMobileApp(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup) throws InterruptedException {
		List<LoginEntity> login = testData.getData().get(LoginEntity.class);
		for (GenericEntity logindata : login) {
			if (logindata.getAction().equalsIgnoreCase("add") && logindata.getStepGroup().equalsIgnoreCase(stepGroup)) {
				NiaLoginPage login1 = new NiaLoginPage(driver, "Create Login");
				login1.fillAndSubmitLoginDetails((LoginEntity) logindata, assertReference, stepGroup, driver);
			}
		}
	}
	

	public void EditLoginNIAMobileApp(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup) throws InterruptedException {
		List<LoginEntity> login = testData.getData().get(LoginEntity.class);
		for (GenericEntity logindata : login) {
			if (logindata.getAction().equalsIgnoreCase("edit") && logindata.getStepGroup().equalsIgnoreCase(stepGroup)) {
				NiaLoginPage login1 = new NiaLoginPage(driver, "Edit Login");
				login1.fillAndSubmitLoginDetails((LoginEntity) logindata, assertReference, stepGroup,driver);
			}
		}
	}

	public void VerifyLoginNIAMobileApp(TestData testData, ExecutionTestSteps executionTestStep, CustomAssert assertReference, AppiumDriver driver, String stepGroup)
			throws InterruptedException {
		List<LoginEntity> login = testData.getData().get(LoginEntity.class);
		for (GenericEntity logindata :  login) {
			if (logindata.getAction().equalsIgnoreCase("verify") && logindata.getStepGroup().equalsIgnoreCase(stepGroup)) {
				NiaLoginPage login1 = new NiaLoginPage(driver, "Verify Login");
				login1.fillAndSubmitLoginDetails((LoginEntity) logindata, assertReference, stepGroup,driver);
			}
		}

	}

	// Create Two Wheeler
	public void CreateTwoWheelerBasicPremium(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)
			throws InterruptedException {
		List<? extends GenericEntity> twoWheelerBasicPremium = testData.getData().get(TwoWheelerBasicPremiumEntity.class);
		for (GenericEntity twoWheelerBasicPremiumdata : twoWheelerBasicPremium) {
			if (twoWheelerBasicPremiumdata.getAction().equalsIgnoreCase("add") && twoWheelerBasicPremiumdata.getStepGroup().equalsIgnoreCase(stepGroup)) {
				TwoWheelerBasicPremiumPage twoWheelerBasicPremiumPage = new TwoWheelerBasicPremiumPage(driver,"Create Two Wheeler Basic Premium");
				twoWheelerBasicPremiumPage.fillAndSubmitTwoWheelerBasicPremiumPageDetails((TwoWheelerBasicPremiumEntity) twoWheelerBasicPremiumdata, assertReference);
			}
		}
	}

	public void EditTwoWheelerBasicPremium(TestData testData, ExecutionTestSteps executionTestStep,
			CustomAssert assertReference, AppiumDriver driver, String stepGroup) throws InterruptedException {
		List<? extends GenericEntity> twoWheelerBasicPremium = testData.getData().get(TwoWheelerBasicPremiumEntity.class);
		for (GenericEntity twoWheelerBasicPremiumdata : twoWheelerBasicPremium) {
			if (twoWheelerBasicPremiumdata.getAction().equalsIgnoreCase("edit") && twoWheelerBasicPremiumdata.getStepGroup().equalsIgnoreCase(stepGroup)) {
				TwoWheelerBasicPremiumPage twoWheelerBasicPremiumPage = new TwoWheelerBasicPremiumPage(driver,"Create Two Wheeler Basic Premium");
				twoWheelerBasicPremiumPage.fillAndSubmitTwoWheelerBasicPremiumPageDetails((TwoWheelerBasicPremiumEntity) twoWheelerBasicPremiumdata, assertReference);
			}
		}
	}

	public void VerifyTwoWheelerBasicPremium(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> twoWheelerBasicPremium = testData.getData().get(TwoWheelerBasicPremiumEntity.class);
		for (GenericEntity twoWheelerBasicPremiumdata : twoWheelerBasicPremium) {
			if (twoWheelerBasicPremiumdata.getAction().equalsIgnoreCase("verify") && twoWheelerBasicPremiumdata.getStepGroup().equalsIgnoreCase(stepGroup)) {
				TwoWheelerBasicPremiumPage twoWheelerBasicPremiumPage = new TwoWheelerBasicPremiumPage(driver,"Create Two Wheeler Basic Premium");
				twoWheelerBasicPremiumPage.fillAndSubmitTwoWheelerBasicPremiumPageDetails((TwoWheelerBasicPremiumEntity) twoWheelerBasicPremiumdata, assertReference);
			}
		}
	}

	public void CreateTwoWheelerBuyInsurance(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> twoWheelerBuyInsurance = testData.getData().get(TwoWheelerBuyInsuranceEntity.class);
		for (GenericEntity twoWheelerBuyInsurancedata : twoWheelerBuyInsurance) {
			if (twoWheelerBuyInsurancedata.getAction().equalsIgnoreCase("add") && twoWheelerBuyInsurancedata.getStepGroup().equalsIgnoreCase(stepGroup)) {
				TwoWheelerBuyInsurancePage twoWheelerBuyInsurancePage = new TwoWheelerBuyInsurancePage(driver,"Create Two Wheeler Basic Premium");
				twoWheelerBuyInsurancePage.fillAndSubmitTwoWheelerBuyInsuranceDetails((TwoWheelerBuyInsuranceEntity) twoWheelerBuyInsurancedata, assertReference);
			}
		}
	}

	public void EditTwoWheelerBuyInsurance(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> twoWheelerBuyInsurance = testData.getData().get(TwoWheelerBuyInsuranceEntity.class);
		for (GenericEntity twoWheelerBuyInsurancedata : twoWheelerBuyInsurance) {
			if (twoWheelerBuyInsurancedata.getAction().equalsIgnoreCase("edit") && twoWheelerBuyInsurancedata.getStepGroup().equalsIgnoreCase(stepGroup)) {
				TwoWheelerBuyInsurancePage twoWheelerBuyInsurancePage = new TwoWheelerBuyInsurancePage(driver,"Create Two Wheeler Basic Premium");
				twoWheelerBuyInsurancePage.fillAndSubmitTwoWheelerBuyInsuranceDetails((TwoWheelerBuyInsuranceEntity) twoWheelerBuyInsurancedata, assertReference);
			}
		}
	}

	public void VerifyTwoWheelerBuyInsurance(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> twoWheelerBuyInsurance = testData.getData().get(TwoWheelerBuyInsuranceEntity.class);
		for (GenericEntity twoWheelerBuyInsurancedata : twoWheelerBuyInsurance) {
			if (twoWheelerBuyInsurancedata.getAction().equalsIgnoreCase("verify") && twoWheelerBuyInsurancedata.getStepGroup().equalsIgnoreCase(stepGroup)) {
				TwoWheelerBuyInsurancePage twoWheelerBuyInsurancePage = new TwoWheelerBuyInsurancePage(driver,"Create Two Wheeler Basic Premium");
				twoWheelerBuyInsurancePage.fillAndSubmitTwoWheelerBuyInsuranceDetails((TwoWheelerBuyInsuranceEntity) twoWheelerBuyInsurancedata, assertReference);
			}
		}
	}

	// BuyNowPage

	public void CreateBuyNowPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> buyNowEntity = testData.getData().get(BuyNowEntity.class);
		for (GenericEntity buyNowData : buyNowEntity) {
			if (buyNowData.getAction().equalsIgnoreCase("add") && buyNowData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				BuyNowPage buyNowPage = new BuyNowPage(driver, "Create Buy Now");
				buyNowPage.fillAndSubmitBuyDetails((BuyNowEntity) buyNowData, assertReference, stepGroup);
			}
		}
	}

	public void EditBuyNowPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup) throws InterruptedException {
		List<? extends GenericEntity> buyNowEntity = testData.getData().get(BuyNowEntity.class);
		for (GenericEntity buyNowData : buyNowEntity) {
			if (buyNowData.getAction().equalsIgnoreCase("edit") && buyNowData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				BuyNowPage buyNowPage = new BuyNowPage(driver, "Create Buy Now");
				buyNowPage.fillAndSubmitBuyDetails((BuyNowEntity) buyNowData, assertReference, stepGroup);
			}
		}
	}

	public void VerifyBuyNowPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup) throws InterruptedException {
		List<? extends GenericEntity> buyNowEntity = testData.getData().get(BuyNowEntity.class);
		for (GenericEntity buyNowData : buyNowEntity) {
			if (buyNowData.getAction().equalsIgnoreCase("verify") && buyNowData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				BuyNowPage buyNowPage = new BuyNowPage(driver, "Create Buy Now");
				buyNowPage.fillAndSubmitBuyDetails((BuyNowEntity) buyNowData, assertReference, stepGroup);

			}
		}
	}
	//Buy Intermediary
	public void CreateBuyNowInterPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> buyNowInterEntity = testData.getData().get(BuyNowInterEntity.class);
		for (GenericEntity buyNowInterData : buyNowInterEntity) {
			if (buyNowInterData.getAction().equalsIgnoreCase("add") && buyNowInterData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				BuyNowIntermediaryPage buyNowInterPage = new BuyNowIntermediaryPage(driver, "Create Buy Now");
				buyNowInterPage.fillAndSubmitBuyDetails((BuyNowInterEntity) buyNowInterData, assertReference, stepGroup);
			}
		}
	}
	public void EditBuyNowInterPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> buyNowInterEntity = testData.getData().get(BuyNowInterEntity.class);
		for (GenericEntity buyNowInterData : buyNowInterEntity) {
			if (buyNowInterData.getAction().equalsIgnoreCase("edit") && buyNowInterData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				BuyNowIntermediaryPage buyNowInterPage = new BuyNowIntermediaryPage(driver, "Create Buy Now");
				buyNowInterPage.fillAndSubmitBuyDetails((BuyNowInterEntity) buyNowInterData, assertReference, stepGroup);
			}
		}
	}
		public void VerifyBuyNowInterPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
			List<? extends GenericEntity> buyNowInterEntity = testData.getData().get(BuyNowInterEntity.class);
			for (GenericEntity buyNowInterData : buyNowInterEntity) {
				if (buyNowInterData.getAction().equalsIgnoreCase("verify") && buyNowInterData.getStepGroup().equalsIgnoreCase(stepGroup)) {
					BuyNowIntermediaryPage buyNowInterPage = new BuyNowIntermediaryPage(driver, "Create Buy Now");
					buyNowInterPage.fillAndSubmitBuyDetails((BuyNowInterEntity) buyNowInterData, assertReference, stepGroup);
				}
			}
		}
	//Premium Calculator
	public void CreatePremiumCalculatorPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> premiumCalEntity = testData.getData().get(PremiumCalEntity.class);
		for (GenericEntity premiumCalEntityData : premiumCalEntity) {
			if (premiumCalEntityData.getAction().equalsIgnoreCase("add") && premiumCalEntityData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				PremiumCalHealthPage premiumCalPage = new PremiumCalHealthPage(driver, "Create Buy Now");
				premiumCalPage.fillAndSubmitPremiumCalculDetails((PremiumCalEntity) premiumCalEntityData, assertReference, stepGroup);
			}
		}
	}
	public void EditPremiumCalculatorPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> premiumCalEntity = testData.getData().get(PremiumCalEntity.class);
		for (GenericEntity premiumCalEntityData : premiumCalEntity) {
			if (premiumCalEntityData.getAction().equalsIgnoreCase("edit") && premiumCalEntityData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				PremiumCalHealthPage premiumCalPage = new PremiumCalHealthPage(driver, "Create Buy Now");
				premiumCalPage.fillAndSubmitPremiumCalculDetails((PremiumCalEntity) premiumCalEntityData, assertReference, stepGroup);
			}
		}
	}
	public void VerifyPremiumCalculatorPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> premiumCalEntity = testData.getData().get(PremiumCalEntity.class);
		for (GenericEntity premiumCalEntityData : premiumCalEntity) {
			if (premiumCalEntityData.getAction().equalsIgnoreCase("verify") && premiumCalEntityData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				PremiumCalHealthPage premiumCalPage = new PremiumCalHealthPage(driver, "Create Buy Now");
				premiumCalPage.fillAndSubmitPremiumCalculDetails((PremiumCalEntity) premiumCalEntityData, assertReference, stepGroup);
			}
		}
	}

	// Home Page
	public void CreateHomePage	(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> homepageEntity = testData.getData().get(HomepageEntity.class);
		for (GenericEntity homepageEntityData : homepageEntity) {
			if (homepageEntityData.getAction().equalsIgnoreCase("add") && homepageEntityData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				HomePage homePage = new HomePage(driver, "Create Homepage");
				homePage.fillAndSubmitHomepageDetails((HomepageEntity) homepageEntityData, assertReference, stepGroup);

			}
		}
	}

	public void EditHomePage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup) throws InterruptedException {
		List<? extends GenericEntity> homepageEntity = testData.getData().get(HomepageEntity.class);
		for (GenericEntity homepageEntityData : homepageEntity) {
			if (homepageEntityData.getAction().equalsIgnoreCase("edit")	&& homepageEntityData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				HomePage homePage = new HomePage(driver, "Edit Homepage");
				homePage.fillAndSubmitHomepageDetails((HomepageEntity) homepageEntityData, assertReference, stepGroup);

			}
		}
	}

	public void VerifyHomePage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> homepageEntity = testData.getData().get(HomepageEntity.class);
		for (GenericEntity homepageEntityData : homepageEntity) {
			if (homepageEntityData.getAction().equalsIgnoreCase("verify") && homepageEntityData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				HomePage homePage = new HomePage(driver, "Verify Homepage");
				homePage.fillAndSubmitHomepageDetails((HomepageEntity) homepageEntityData, assertReference, stepGroup);
			}
		}
	}
	
	// NewIndiaTopUpMediclaim
	public void CreateNewIndiaTopUpMediclaimPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> newIndiaTopUpMedicClaimEntity = testData.getData().get(TopUpMediEntity.class);
		for (GenericEntity newIndiaTopUpMediclaimData : newIndiaTopUpMedicClaimEntity) {
			if (newIndiaTopUpMediclaimData.getAction().equalsIgnoreCase("add") && newIndiaTopUpMediclaimData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				NewIndiaTopUpMediclaimPage newIndiaTopUpMediclaimPage = new NewIndiaTopUpMediclaimPage(driver,"Create New India Top Up Mediclaim");
				newIndiaTopUpMediclaimPage.fillAndSubmitDetailedQuoteDetails((TopUpMediEntity) newIndiaTopUpMediclaimData, assertReference, stepGroup); 
				//newIndiaTopUpMediclaimPage.fetchQuoteNumber(newIndiaTopUpMediclaimData);
				//testData.updateRecordsForCriteria(newIndiaTopUpMediclaimData);
				//setEditQuoteNoDependency(newIndiaTopUpMediclaimData, testData);


			}
		}
	}

	public void EditNewIndiaTopUpMediclaimPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup) throws InterruptedException {
		List<? extends GenericEntity> newIndiaTopUpMedicClaimEntity = testData.getData().get(TopUpMediEntity.class);
		for (GenericEntity newIndiaTopUpMediclaimData : newIndiaTopUpMedicClaimEntity) {
			if (newIndiaTopUpMediclaimData.getAction().equalsIgnoreCase("edit")	&& newIndiaTopUpMediclaimData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				NewIndiaTopUpMediclaimPage newIndiaTopUpMediclaimPage = new NewIndiaTopUpMediclaimPage(driver,"Create New India Top Up Mediclaim");
				newIndiaTopUpMediclaimPage.fillAndSubmitDetailedQuoteDetails((TopUpMediEntity) newIndiaTopUpMedicClaimEntity, assertReference, stepGroup);
				testData.updateRecordsForCriteria(newIndiaTopUpMediclaimData);
				setEditQuoteNoDependency(newIndiaTopUpMediclaimData, testData);
			}
		}
	}

	public void VerifyNewIndiaTopUpMediclaimPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> newIndiaTopUpMedicClaimEntity = testData.getData().get(TopUpMediEntity.class);
		for (GenericEntity newIndiaTopUpMediclaimData : newIndiaTopUpMedicClaimEntity) {
			if (newIndiaTopUpMediclaimData.getAction().equalsIgnoreCase("verify") && newIndiaTopUpMediclaimData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				NewIndiaTopUpMediclaimPage newIndiaTopUpMediclaimPage = new NewIndiaTopUpMediclaimPage(driver,"Create New India Top Up Mediclaim");
				newIndiaTopUpMediclaimPage.fillAndSubmitDetailedQuoteDetails((TopUpMediEntity) newIndiaTopUpMedicClaimEntity, assertReference, stepGroup);
				testData.updateRecordsForCriteria(newIndiaTopUpMediclaimData);
				setEditQuoteNoDependency(newIndiaTopUpMediclaimData, testData);
			}
		}
	}

	//DetailedTravelDetailsPage

	public void CreateDetailedTravelDetailsPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> detailedTravelDetailsEntity=testData.getData().get(DetailedTravelEntity.class);
		for(GenericEntity detailedTravelDetailsData:detailedTravelDetailsEntity){
			if(detailedTravelDetailsData.getAction().equalsIgnoreCase("add") && detailedTravelDetailsData.getStepGroup().equalsIgnoreCase(stepGroup)){
				DetailedTravelDetailsPage detailedTravelDetailsPage = new DetailedTravelDetailsPage(driver, "Detailed Travel Details");
				detailedTravelDetailsPage.fillAndSubmitDetailedTravelDetailsDetails((DetailedTravelEntity) detailedTravelDetailsData, assertReference, stepGroup);		

			}
		}
	}

	public void EditDetailedTravelDetailsPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> detailedTravelDetailsEntity=testData.getData().get(DetailedTravelEntity.class);
		for(GenericEntity detailedTravelDetailsData:detailedTravelDetailsEntity){
			if(detailedTravelDetailsData.getAction().equalsIgnoreCase("edit") && detailedTravelDetailsData.getStepGroup().equalsIgnoreCase(stepGroup)){
				DetailedTravelDetailsPage detailedTravelDetailsPage = new DetailedTravelDetailsPage(driver, "Detailed Travel Details");
				detailedTravelDetailsPage.fillAndSubmitDetailedTravelDetailsDetails((DetailedTravelEntity) detailedTravelDetailsEntity, assertReference, stepGroup);		

			}        
		}
	}
	public void VerifyDetailedTravelDetailsPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> detailedTravelDetailsEntity=testData.getData().get(DetailedTravelEntity.class);
		for(GenericEntity detailedTravelDetailsData:detailedTravelDetailsEntity){
			if(detailedTravelDetailsData.getAction().equalsIgnoreCase("verify") && detailedTravelDetailsData.getStepGroup().equalsIgnoreCase(stepGroup)){
				DetailedTravelDetailsPage detailedTravelDetailsPage = new DetailedTravelDetailsPage(driver, "Detailed Travel Details");
				detailedTravelDetailsPage.fillAndSubmitDetailedTravelDetailsDetails((DetailedTravelEntity) detailedTravelDetailsEntity, assertReference, stepGroup);		


			}
		}
	}
	//PrivateCar
	public void CreatePrivateCarPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> privateCarEntity = testData.getData().get(PrivateCarEntity.class);
		for (GenericEntity privateCarEntity_Data : privateCarEntity) {
			if (privateCarEntity_Data.getAction().equalsIgnoreCase("add") && privateCarEntity_Data.getStepGroup().equalsIgnoreCase(stepGroup)) {
				PrivateCarPage privateCarPage = new PrivateCarPage(driver, "Private Car");
				privateCarPage.fillAndSubmitPrivateCarPageDetails((PrivateCarEntity)privateCarEntity_Data, assertReference, stepGroup);
			}
		}
	}

	public void EditPrivateCarPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup) throws InterruptedException {
		List<? extends GenericEntity> privateCarEntity = testData.getData().get(PrivateCarEntity.class);
		for (GenericEntity privateCarEntity_Data : privateCarEntity) {
			if (privateCarEntity_Data.getAction().equalsIgnoreCase("edit") && privateCarEntity_Data.getStepGroup().equalsIgnoreCase(stepGroup)) {
				PrivateCarPage privateCarPage = new PrivateCarPage(driver, "Private Car");
				privateCarPage.fillAndSubmitPrivateCarPageDetails((PrivateCarEntity)privateCarEntity_Data, assertReference, stepGroup);
			}
		}
	}

	public void VerifyPrivateCarPage(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup) throws InterruptedException {
		List<? extends GenericEntity> privateCarEntity = testData.getData().get(PrivateCarEntity.class);
		for (GenericEntity privateCarEntity_Data : privateCarEntity) {
			if (privateCarEntity_Data.getAction().equalsIgnoreCase("ver") && privateCarEntity_Data.getStepGroup().equalsIgnoreCase(stepGroup)) {
				PrivateCarPage privateCarPage = new PrivateCarPage(driver, "Private Car");
				privateCarPage.fillAndSubmitPrivateCarPageDetails((PrivateCarEntity)privateCarEntity_Data, assertReference, stepGroup);
			}
		}
	}
	//PremiumSummary
	public void CreatePremiumSummaryPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> premiumSummaryEntity=testData.getData().get(PremiumSummaryEntity.class);
		for(GenericEntity premiumSummaryEntityData:premiumSummaryEntity){
			if(premiumSummaryEntityData.getAction().equalsIgnoreCase("add") && premiumSummaryEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				PremiumSummaryPage premiumSummaryPage = new PremiumSummaryPage(driver, "Premium Summary");
				premiumSummaryPage.fillAndSubmitPremiumSummaryPageDetails((PremiumSummaryEntity)premiumSummaryEntityData, assertReference, stepGroup,testData);		
				setEditPaymentDependency((PremiumSummaryEntity) premiumSummaryEntityData, testData);

			}
		}
	}
	public void EditPremiumSummaryPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> premiumSummaryEntity=testData.getData().get(PremiumSummaryEntity.class);
		for(GenericEntity premiumSummaryEntityData:premiumSummaryEntity){
			if(premiumSummaryEntityData.getAction().equalsIgnoreCase("edit") && premiumSummaryEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				PremiumSummaryPage premiumSummaryPage = new PremiumSummaryPage(driver, "Premium Summary");
				premiumSummaryPage.fillAndSubmitPremiumSummaryPageDetails((PremiumSummaryEntity)premiumSummaryEntity, assertReference, stepGroup,testData);		

			}
		}
	}
	public void VerifyPremiumSummaryPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> premiumSummaryEntity=testData.getData().get(PremiumSummaryEntity.class);
		for(GenericEntity premiumSummaryEntityData:premiumSummaryEntity){
			if(premiumSummaryEntityData.getAction().equalsIgnoreCase("verify") && premiumSummaryEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				PremiumSummaryPage premiumSummaryPage = new PremiumSummaryPage(driver, "Premium Summary");
				premiumSummaryPage.fillAndSubmitPremiumSummaryPageDetails((PremiumSummaryEntity)premiumSummaryEntity, assertReference, stepGroup,testData);		

			}
		}
	}

	//TopUpHealthAdditionalDeatils

	public void CreateTopUpHealthAdditionalDeatils(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> healthAddDetailEntity = testData.getData().get(HealthAddDetailEntity.class);
		for (GenericEntity healthAddDetailData : healthAddDetailEntity) {
			if (healthAddDetailData.getAction().equalsIgnoreCase("add") && healthAddDetailData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				TopUpHealthAdditionalDeatils topUpHealthAdditionalDeatils = new TopUpHealthAdditionalDeatils(driver, "Top Up Health Assitional Deatils");
				topUpHealthAdditionalDeatils.fillAndSubmitHomepageDetails( (HealthAddDetailEntity) healthAddDetailData, assertReference, stepGroup);
			}
		}
	}

	public void EditTopUpHealthAdditionalDeatils(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> healthAddDetailEntity = testData.getData().get(HealthAddDetailEntity.class);
		for (GenericEntity healthAddDetailData : healthAddDetailEntity) {
			if (healthAddDetailData.getAction().equalsIgnoreCase("edit") && healthAddDetailData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				TopUpHealthAdditionalDeatils topUpHealthAdditionalDeatils = new TopUpHealthAdditionalDeatils(driver, "Top Up Health Assitional Deatils");
				topUpHealthAdditionalDeatils.fillAndSubmitHomepageDetails( (HealthAddDetailEntity) healthAddDetailData, assertReference, stepGroup);
			}
		}
	}

	public void VerifyTopUpHealthAdditionalDeatils(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> healthAddDetailEntity = testData.getData().get(HealthAddDetailEntity.class);
		for (GenericEntity healthAddDetailData : healthAddDetailEntity) {
			if (healthAddDetailData.getAction().equalsIgnoreCase("verify") && healthAddDetailData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				TopUpHealthAdditionalDeatils topUpHealthAdditionalDeatils = new TopUpHealthAdditionalDeatils(driver, "Top Up Health Assitional Deatils");
				topUpHealthAdditionalDeatils.fillAndSubmitHomepageDetails( (HealthAddDetailEntity) healthAddDetailData, assertReference, stepGroup);
			}
		}
	}

	public void CreatePersonalAccidentDet(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> personalAccidentDetEntity = testData.getData().get(PersonalAccidentDetEntity.class);
		for (GenericEntity personalAccidentDetData : personalAccidentDetEntity) {
			if (personalAccidentDetData.getAction().equalsIgnoreCase("add") && personalAccidentDetData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				PersonalAccidentDet personalAccidentDet = new PersonalAccidentDet(driver, "Personal Accident Det");
				personalAccidentDet.fillAndSubmitPersonalAccidentDet((PersonalAccidentDetEntity) personalAccidentDetData, assertReference, stepGroup);
			}
		}
	}

	public void EditPersonalAccidentDet(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> personalAccidentDetEntity = testData.getData().get(PersonalAccidentDetEntity.class);
		for (GenericEntity personalAccidentDetData : personalAccidentDetEntity) {
			if (personalAccidentDetData.getAction().equalsIgnoreCase("add") && personalAccidentDetData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				PersonalAccidentDet personalAccidentDet = new PersonalAccidentDet(driver, "Personal Accident Det");
				personalAccidentDet.fillAndSubmitPersonalAccidentDet((PersonalAccidentDetEntity) personalAccidentDetData, assertReference, stepGroup);
			}
		}
	}

	public void VerifyPersonalAccidentDet(TestData testData, ExecutionTestSteps executionTestStep,CustomAssert assertReference, AppiumDriver driver, String stepGroup)throws InterruptedException {
		List<? extends GenericEntity> personalAccidentDetEntity = testData.getData().get(PersonalAccidentDetEntity.class);
		for (GenericEntity personalAccidentDetData : personalAccidentDetEntity) {
			if (personalAccidentDetData.getAction().equalsIgnoreCase("add") && personalAccidentDetData.getStepGroup().equalsIgnoreCase(stepGroup)) {
				PersonalAccidentDet personalAccidentDet = new PersonalAccidentDet(driver, "Personal Accident Det");
				personalAccidentDet.fillAndSubmitPersonalAccidentDet((PersonalAccidentDetEntity) personalAccidentDetData, assertReference, stepGroup);
			}
		}
	}

	//AdditionalDetails
	public void CreateAdditionalDetailsPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> additionalDetailsMotorEntity=testData.getData().get(AdditionalDetailsMotorEntity.class);
		for(GenericEntity additionalDetailsMotorData:additionalDetailsMotorEntity){
			if(additionalDetailsMotorData.getAction().equalsIgnoreCase("add") && additionalDetailsMotorData.getStepGroup().equalsIgnoreCase(stepGroup)){
				AdditionalDetailsMotorPage additionalDetailsMotorPage = new AdditionalDetailsMotorPage(driver, "Premium Summary");
				additionalDetailsMotorPage.fillAndSubmitAdditionalVehicleDetails((AdditionalDetailsMotorEntity)additionalDetailsMotorData, assertReference, stepGroup);		
			}
		}
	}
	public void EditAdditionalDetailsPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> additionalDetailsMotorEntity=testData.getData().get(AdditionalDetailsMotorEntity.class);
		for(GenericEntity additionalDetailsMotorData:additionalDetailsMotorEntity){
			if(additionalDetailsMotorData.getAction().equalsIgnoreCase("edit") && additionalDetailsMotorData.getStepGroup().equalsIgnoreCase(stepGroup)){
				AdditionalDetailsMotorPage additionalDetailsMotorPage = new AdditionalDetailsMotorPage(driver, "Premium Summary");
				additionalDetailsMotorPage.fillAndSubmitAdditionalVehicleDetails((AdditionalDetailsMotorEntity)additionalDetailsMotorEntity, assertReference, stepGroup);		
			}
		}
	}
	public void VerifyAdditionalDetailsPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> additionalDetailsMotorEntity=testData.getData().get(AdditionalDetailsMotorEntity.class);
		for(GenericEntity additionalDetailsMotorData:additionalDetailsMotorEntity){
			if(additionalDetailsMotorData.getAction().equalsIgnoreCase("verify") && additionalDetailsMotorData.getStepGroup().equalsIgnoreCase(stepGroup)){
				AdditionalDetailsMotorPage additionalDetailsMotorPage = new AdditionalDetailsMotorPage(driver, "Premium Summary");
				additionalDetailsMotorPage.fillAndSubmitAdditionalVehicleDetails((AdditionalDetailsMotorEntity)additionalDetailsMotorEntity, assertReference, stepGroup);		
			}
		}
	}
	//SummaryPage
	public void CreateSummaryPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> summaryPageEntity=testData.getData().get(SummaryPageEntity.class);
		for(GenericEntity summaryPageEntityData:summaryPageEntity){
			if(summaryPageEntityData.getAction().equalsIgnoreCase("add") && summaryPageEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				SummaryPage summaryPage = new SummaryPage(driver, " Summary");
				summaryPage.fillAndSubmitPremiumSummaryPageDetails((SummaryPageEntity)summaryPageEntityData, assertReference, stepGroup);		
			}
		}
	}
	public void EditSummaryPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> summaryPageEntity=testData.getData().get(SummaryPageEntity.class);
		for(GenericEntity summaryPageEntityData:summaryPageEntity){
			if(summaryPageEntityData.getAction().equalsIgnoreCase("Edit") && summaryPageEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				SummaryPage summaryPage = new SummaryPage(driver, " Summary");
				summaryPage.fillAndSubmitPremiumSummaryPageDetails((SummaryPageEntity)summaryPageEntityData, assertReference, stepGroup);		
			}
		}
	}
	public void VerifySummaryPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> summaryPageEntity=testData.getData().get(SummaryPageEntity.class);
		for(GenericEntity summaryPageEntityData:summaryPageEntity){
			if(summaryPageEntityData.getAction().equalsIgnoreCase("Verify") && summaryPageEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				SummaryPage summaryPage = new SummaryPage(driver, " Summary");
				summaryPage.fillAndSubmitPremiumSummaryPageDetails((SummaryPageEntity)summaryPageEntityData, assertReference, stepGroup);		

			}
		}
	}
	public void CreateHomeIntermediaryPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws Exception{
		List<? extends GenericEntity> homeIntermediaryPageEntity=testData.getData().get(HomeIntermediaryEntity.class);
		for(GenericEntity homeIntermediaryPageEntityData:homeIntermediaryPageEntity){
			if(homeIntermediaryPageEntityData.getAction().equalsIgnoreCase("add") && homeIntermediaryPageEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				HomeIntermediaryPage homeIntermediaryPage = new HomeIntermediaryPage(driver, " Home Intermediary Page");
				homeIntermediaryPage.fillAndSubmitHomeIntermediaryPage((HomeIntermediaryEntity)homeIntermediaryPageEntityData, assertReference, stepGroup);	
			}
		}
	}
	public void EditHomeIntermediaryPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws Exception{
		List<? extends GenericEntity> homeIntermediaryPageEntity=testData.getData().get(HomeIntermediaryEntity.class);
		for(GenericEntity homeIntermediaryPageEntityData:homeIntermediaryPageEntity){
			if(homeIntermediaryPageEntityData.getAction().equalsIgnoreCase("add") && homeIntermediaryPageEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				HomeIntermediaryPage homeIntermediaryPage = new HomeIntermediaryPage(driver, " Home Intermediary Page");
				homeIntermediaryPage.fillAndSubmitHomeIntermediaryPage((HomeIntermediaryEntity)homeIntermediaryPageEntityData, assertReference, stepGroup);	
			}
		}
	}

	public void VerifyHomeIntermediaryPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws Exception{
		List<? extends GenericEntity> homeIntermediaryPageEntity=testData.getData().get(HomeIntermediaryEntity.class);
		for(GenericEntity homeIntermediaryPageEntityData:homeIntermediaryPageEntity){
			if(homeIntermediaryPageEntityData.getAction().equalsIgnoreCase("verify") && homeIntermediaryPageEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				HomeIntermediaryPage homeIntermediaryPage = new HomeIntermediaryPage(driver, " Home Intermediary Page");
				homeIntermediaryPage.fillAndSubmitHomeIntermediaryPage((HomeIntermediaryEntity)homeIntermediaryPageEntityData, assertReference, stepGroup);	
			}
		}
	}
	//RecentActivities
	public void CreateRecentActivitiesPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> recentActivitiesEntity=testData.getData().get(RecentActivitiesEntity.class);
		for(GenericEntity recentActivitiesEntityData:recentActivitiesEntity){
			if(recentActivitiesEntityData.getAction().equalsIgnoreCase("add") && recentActivitiesEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				RecentActivitiesPage recentActivitiesPage = new RecentActivitiesPage(driver, " Recent Activities");
				recentActivitiesPage.fillAndSubmitRecentActivitiesPageDetails((RecentActivitiesEntity)recentActivitiesEntity, assertReference, stepGroup);		
			}
		}
	}
	public void EditRecentActivitiesPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> recentActivitiesEntity=testData.getData().get(RecentActivitiesEntity.class);
		for(GenericEntity recentActivitiesEntityData:recentActivitiesEntity){
			if(recentActivitiesEntityData.getAction().equalsIgnoreCase("edit") && recentActivitiesEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				RecentActivitiesPage recentActivitiesPage = new RecentActivitiesPage(driver, " Recent Activities");
				recentActivitiesPage.fillAndSubmitRecentActivitiesPageDetails((RecentActivitiesEntity)recentActivitiesEntity, assertReference, stepGroup);		
			}
		}
	}
	public void VerifyRecentActivitiesPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> recentActivitiesEntity=testData.getData().get(RecentActivitiesEntity.class);
		for(GenericEntity recentActivitiesEntityData:recentActivitiesEntity){
			if(recentActivitiesEntityData.getAction().equalsIgnoreCase("verify") && recentActivitiesEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				RecentActivitiesPage recentActivitiesPage = new RecentActivitiesPage(driver, " Recent Activities");
				recentActivitiesPage.fillAndSubmitRecentActivitiesPageDetails((RecentActivitiesEntity)recentActivitiesEntity, assertReference, stepGroup);		
			}
		}
	}

	/*private void setEditPaymentDependency(PremiumSummaryEntity premiumSummaryEntity, TestData testData) {
		if(premiumSummaryEntity.getStringValueForField("DependencyForPaymentSummary")!=null){
			ArrayList<? extends GenericEntity> summaryPageListAll = testData.getObjectByReference(testData.getSummaryPageEntity(), premiumSummaryEntity.getStringValueForField("DependencyForPaymentSummary"));
			for(GenericEntity summaryPageData:summaryPageListAll) {
				//summaryPageData.setStringValueForField("PolicyStartDate", premiumSummaryEntity.getStringValueForField("PolicyStartDate"));
				//summaryPageData.setStringValueForField("PolicyExpiryDate", premiumSummaryEntity.getStringValueForField("PolicyExpiryDate"));
				summaryPageData.setStringValueForField("QuoteNo", premiumSummaryEntity.getStringValueForField("QuoteNo"));
				testData.updateRecordsForCriteria(summaryPageData);

			}
		}

	}*/


	public void setEditPaymentDependency(GenericEntity userData, TestData testData) {
		if (userData.getStringValueForField("DependencyForPaymentSummary") != null) {
			List<? extends GenericEntity> summaryPageEntityList = testData.getObjectByReference(testData.getData().get(SummaryPageEntity.class),userData.getStringValueForField("DependencyForPaymentSummary"));
			for (GenericEntity summaryPageData : summaryPageEntityList) {
				summaryPageData.setStringValueForField("QuoteNo",userData.getStringValueForField("QuoteNo"));
				testData.updateRecordsForCriteria(summaryPageData);
			}
		}
	}	
	//getBuyNowEntermidiaryEntity

	public void CreateBuyNowIntermidary(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> buyNowEntermidiaryEntity=testdata.getData().get(BuyNowEntermidiaryEntity.class);
		for(GenericEntity buynowEntermidiary:buyNowEntermidiaryEntity ) {
			if(buynowEntermidiary.getAction().equalsIgnoreCase("add")&& buynowEntermidiary.getStepGroup().equalsIgnoreCase(stepGroup)){
				GrihaSuvidhaBuyNowPages grihaSuvidhaBuyNowPages=new GrihaSuvidhaBuyNowPages(driver, "Buy Now inter");
				grihaSuvidhaBuyNowPages.fillandproceedBuyNow((BuyNowEntermidiaryEntity)buynowEntermidiary, assertReference);	
			}
		}
	}

	public void EditBuyNowIntermidary(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> buyNowEntermidiaryEntity=testdata.getData().get(BuyNowEntermidiaryEntity.class);
		for(GenericEntity buynowEntermidiary:buyNowEntermidiaryEntity ) {
			if(buynowEntermidiary.getAction().equalsIgnoreCase("edit")&& buynowEntermidiary.getStepGroup().equalsIgnoreCase(stepGroup)){
				GrihaSuvidhaBuyNowPages grihaSuvidhaBuyNowPages=new GrihaSuvidhaBuyNowPages(driver, "Buy Now inter");
				grihaSuvidhaBuyNowPages.fillandproceedBuyNow((BuyNowEntermidiaryEntity)buynowEntermidiary, assertReference);	
			}
		}
	}
	public void verifyBuyNowIntermidary(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> buyNowEntermidiaryEntity=testdata.getData().get(BuyNowEntermidiaryEntity.class);
		for(GenericEntity buynowEntermidiary:buyNowEntermidiaryEntity ) {
			if(buynowEntermidiary.getAction().equalsIgnoreCase("verify")&& buynowEntermidiary.getStepGroup().equalsIgnoreCase(stepGroup)){
				GrihaSuvidhaBuyNowPages grihaSuvidhaBuyNowPages=new GrihaSuvidhaBuyNowPages(driver, "Buy Now inter");
				grihaSuvidhaBuyNowPages.fillandproceedBuyNow((BuyNowEntermidiaryEntity)buynowEntermidiary, assertReference);	
			}
		}
	}

	//frist page of additonal detail wrriten by anzaf
	public void CreateadditionalDetailsPageForIntermidiary(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> additionalDetailsPageForIntermidiaryEntity=testdata.getData().get(AdtionalDetalsInterEntity.class);
		for(GenericEntity addtionaldetail:additionalDetailsPageForIntermidiaryEntity ) {
			if(addtionaldetail.getAction().equalsIgnoreCase("add")&& addtionaldetail.getStepGroup().equalsIgnoreCase(stepGroup)){
				AdditionalDetailsPageForIntermidiary additionalDetailsPageForIntermidiary=new AdditionalDetailsPageForIntermidiary(driver, "Additional detail");
				additionalDetailsPageForIntermidiary.fillAndSubmitAddtionalDetailPage((AdtionalDetalsInterEntity)addtionaldetail, assertReference);	
			}
		}
	}
	public void EditadditionalDetailsPageForIntermidiary(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> additionalDetailsPageForIntermidiaryEntity=testdata.getData().get(AdtionalDetalsInterEntity.class);
		for(GenericEntity addtionaldetail:additionalDetailsPageForIntermidiaryEntity ) {
			if(addtionaldetail.getAction().equalsIgnoreCase("edit")&& addtionaldetail.getStepGroup().equalsIgnoreCase(stepGroup)){
				AdditionalDetailsPageForIntermidiary additionalDetailsPageForIntermidiary=new AdditionalDetailsPageForIntermidiary(driver, "Additional detail");
				additionalDetailsPageForIntermidiary.fillAndSubmitAddtionalDetailPage((AdtionalDetalsInterEntity)addtionaldetail, assertReference);	
			}
		}
	}
	public void verifyadditionalDetailsPageForIntermidiary(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> additionalDetailsPageForIntermidiaryEntity=testdata.getData().get(AdtionalDetalsInterEntity.class);
		for(GenericEntity addtionaldetail:additionalDetailsPageForIntermidiaryEntity ) {
			if(addtionaldetail.getAction().equalsIgnoreCase("verify")&& addtionaldetail.getStepGroup().equalsIgnoreCase(stepGroup)){
				AdditionalDetailsPageForIntermidiary additionalDetailsPageForIntermidiary=new AdditionalDetailsPageForIntermidiary(driver, "Additional detail");
				additionalDetailsPageForIntermidiary.fillAndSubmitAddtionalDetailPage((AdtionalDetalsInterEntity)addtionaldetail, assertReference);	
			}
		}
	}
/*public void createPolicyHolderInformationIntermidiaryDetails(TestData testData,ExecutionTestSteps executionTestStep, CustomAssert assertReference, AppiumDriver driver, String stepGroup,String deviceOS) {
	List<? extends GenericEntity> policyHolderInformationIntermidiaryEntity=testData.getPolicyInfoIntermidiaryEntity(PolicyInfoIntermidiaryEntity.class);
	for(GenericEntity policyHolderInformationIntermidiar:policyHolderInformationIntermidiaryEntity ) {
		if(policyHolderInformationIntermidiar.getAction().equalsIgnoreCase("add")&& policyHolderInformationIntermidiar.getStepGroup().equalsIgnoreCase(stepGroup)){
			PolicyHolderInformationIntermidiarypage additionalDetailsPageForIntermidiary=new PolicyHolderInformationIntermidiarypage(driver, "PolicyHolderInformation", deviceOS);
			additionalDetailsPageForIntermidiary.fillAndSubmitHolderInformationIntermidiaryEntity((PolicyInfoIntermidiaryEntity)policyHolderInformationIntermidiar, assertReference);	
		}
	}*/
	// TODO Auto-generated method stub
	


	//Second Page 
	public void createPolicyHolderInformationIntermidiary(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws Exception{
		List<? extends GenericEntity> policyHolderInformationIntermidiaryEntity=testdata.getData().get(PolicyInfoIntermidiaryEntity.class);
		for(GenericEntity policyHolderInformationIntermidiar:policyHolderInformationIntermidiaryEntity ) {
			if(policyHolderInformationIntermidiar.getAction().equalsIgnoreCase("add")&& policyHolderInformationIntermidiar.getStepGroup().equalsIgnoreCase(stepGroup)){
				PolicyHolderInformationIntermidiarypage additionalDetailsPageForIntermidiary=new PolicyHolderInformationIntermidiarypage(driver, "PolicyHolderInformation");
				additionalDetailsPageForIntermidiary.fillAndSubmitHolderInformationIntermidiaryEntity((PolicyInfoIntermidiaryEntity)policyHolderInformationIntermidiar, assertReference);	
			}
		}
	}
	public void editPolicyHolderInformationIntermidiary(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws Exception{
		List<? extends GenericEntity> policyHolderInformationIntermidiaryEntity=testdata.getData().get(PolicyInfoIntermidiaryEntity.class);
		for(GenericEntity policyHolderInformationIntermidiar:policyHolderInformationIntermidiaryEntity ) {
			if(policyHolderInformationIntermidiar.getAction().equalsIgnoreCase("edit")&& policyHolderInformationIntermidiar.getStepGroup().equalsIgnoreCase(stepGroup)){
				PolicyHolderInformationIntermidiarypage additionalDetailsPageForIntermidiary=new PolicyHolderInformationIntermidiarypage(driver, "PolicyHolderInformation");
				additionalDetailsPageForIntermidiary.fillAndSubmitHolderInformationIntermidiaryEntity((PolicyInfoIntermidiaryEntity)policyHolderInformationIntermidiar, assertReference);	
			}
		}
	}


	public void verifyPolicyHolderInformationIntermidiary(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws Exception{
		List<? extends GenericEntity> policyHolderInformationIntermidiaryEntity=testdata.getData().get(PolicyInfoIntermidiaryEntity.class);
		for(GenericEntity policyHolderInformationIntermidiar:policyHolderInformationIntermidiaryEntity ) {
			if(policyHolderInformationIntermidiar.getAction().equalsIgnoreCase("verify")&& policyHolderInformationIntermidiar.getStepGroup().equalsIgnoreCase(stepGroup)){
				PolicyHolderInformationIntermidiarypage additionalDetailsPageForIntermidiary=new PolicyHolderInformationIntermidiarypage(driver, "PolicyHolderInformation");
				additionalDetailsPageForIntermidiary.fillAndSubmitHolderInformationIntermidiaryEntity((PolicyInfoIntermidiaryEntity)policyHolderInformationIntermidiar, assertReference);	
			}

		}
	}


	public void CreateAddressFinencierDetail(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> addressFinancierDetailEntity=testdata.getData().get(AddressFinancierDetailEntity.class);
		for(GenericEntity addressFinancierDetail:addressFinancierDetailEntity ) {
			if(addressFinancierDetail.getAction().equalsIgnoreCase("add")&& addressFinancierDetail.getStepGroup().equalsIgnoreCase(stepGroup)){
				AddressFinancierDetailPage addressFinancierDetailPage=new AddressFinancierDetailPage(driver, "PolicyHolderInformation");
				addressFinancierDetailPage.fillandSubmitAddressFinancierDetil((AddressFinancierDetailEntity) addressFinancierDetail, assertReference);	
			}
		}
	}

	public void editAddressFinencierDetail(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> addressFinancierDetailEntity=testdata.getData().get(AddressFinancierDetailEntity.class);
		for(GenericEntity addressFinancierDetail:addressFinancierDetailEntity ) {
			if(addressFinancierDetail.getAction().equalsIgnoreCase("edit")&& addressFinancierDetail.getStepGroup().equalsIgnoreCase(stepGroup)){
				AddressFinancierDetailPage addressFinancierDetailPage=new AddressFinancierDetailPage(driver, "PolicyHolderInformation");
				addressFinancierDetailPage.fillandSubmitAddressFinancierDetil((AddressFinancierDetailEntity) addressFinancierDetail, assertReference);	
			}

		}
	}



	public void verifyAddressFinencierDetail(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> addressFinancierDetailEntity=testdata.getData().get(AddressFinancierDetailEntity.class);
		for(GenericEntity addressFinancierDetail:addressFinancierDetailEntity ) {
			if(addressFinancierDetail.getAction().equalsIgnoreCase("verify")&& addressFinancierDetail.getStepGroup().equalsIgnoreCase(stepGroup)){
				AddressFinancierDetailPage addressFinancierDetailPage=new AddressFinancierDetailPage(driver, "PolicyHolderInformation");
				addressFinancierDetailPage.fillandSubmitAddressFinancierDetil((AddressFinancierDetailEntity) addressFinancierDetail, assertReference);	
			}

		}
	}


	public void CreateSummaryIntermidiateDetail(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> summaryIntermidiarEntity=testdata.getData().get(SummaryIntermidiarEntity.class);
		for(GenericEntity summaryIntermidiarDetail:summaryIntermidiarEntity ) {
			if(summaryIntermidiarDetail.getAction().equalsIgnoreCase("add")&& summaryIntermidiarDetail.getStepGroup().equalsIgnoreCase(stepGroup)){
				SummaryPymentDetailInterPage summaryPymentDetailInterPage=new SummaryPymentDetailInterPage(driver, "SummaryPymentDetailInter");
				summaryPymentDetailInterPage.fillAndSubmitPremiumSummaryPageDetails((SummaryIntermidiarEntity)summaryIntermidiarDetail, assertReference, stepGroup);
			}

		}
	}

	public void EditSummaryIntermidiateDetail(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> summaryIntermidiarEntity=testdata.getData().get(SummaryIntermidiarEntity.class);
		for(GenericEntity summaryIntermidiarDetail:summaryIntermidiarEntity ) {
			if(summaryIntermidiarDetail.getAction().equalsIgnoreCase("edit")&& summaryIntermidiarDetail.getStepGroup().equalsIgnoreCase(stepGroup)){
				SummaryPymentDetailInterPage summaryPymentDetailInterPage=new SummaryPymentDetailInterPage(driver, "SummaryPymentDetailInter");
				summaryPymentDetailInterPage.fillAndSubmitPremiumSummaryPageDetails((SummaryIntermidiarEntity)summaryIntermidiarDetail, assertReference, stepGroup);
			}

		}
	}


	public void VerifySummaryIntermidiateDetail(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> summaryIntermidiarEntity=testdata.getData().get(SummaryIntermidiarEntity.class);
		for(GenericEntity summaryIntermidiarDetail:summaryIntermidiarEntity ) {
			if(summaryIntermidiarDetail.getAction().equalsIgnoreCase("verify")&& summaryIntermidiarDetail.getStepGroup().equalsIgnoreCase(stepGroup)){
				SummaryPymentDetailInterPage summaryPymentDetailInterPage=new SummaryPymentDetailInterPage(driver, "SummaryPymentDetailInter");
				summaryPymentDetailInterPage.fillAndSubmitPremiumSummaryPageDetails((SummaryIntermidiarEntity)summaryIntermidiarDetail, assertReference, stepGroup);
			}

		}
	}





	public void CreateCollectionDetail(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> collectionIntemidiaryEntity=testdata.getData().get(CollectionIntemidiaryEntity.class);
		for(GenericEntity collectionIntemidiaryEntityData:collectionIntemidiaryEntity ) {
			if(collectionIntemidiaryEntityData.getAction().equalsIgnoreCase("add")&& collectionIntemidiaryEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				CollectionIntemidiaryPage collectionIntemidiaryPage=new CollectionIntemidiaryPage(driver, "Collection");
					 collectionIntemidiaryPage.fillAndSubmitCollectionPageDetails((CollectionIntemidiaryEntity)collectionIntemidiaryEntityData, assertReference, stepGroup);
			}

		}
	}



	public void editCollectionDetail(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> collectionIntemidiaryEntity=testdata.getData().get(CollectionIntemidiaryEntity.class);
		for(GenericEntity collectionIntemidiaryEntityData:collectionIntemidiaryEntity ) {
			if(collectionIntemidiaryEntityData.getAction().equalsIgnoreCase("edit")&& collectionIntemidiaryEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				CollectionIntemidiaryPage collectionIntemidiaryPage=new CollectionIntemidiaryPage(driver, "Collection");
					 collectionIntemidiaryPage.fillAndSubmitCollectionPageDetails((CollectionIntemidiaryEntity)collectionIntemidiaryEntityData, assertReference, stepGroup);
			}

		}
	}




	public void verifyCollectionDetail(TestData testdata,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup )throws InterruptedException{
		List<? extends GenericEntity> collectionIntemidiaryEntity=testdata.getData().get(CollectionIntemidiaryEntity.class);
		for(GenericEntity collectionIntemidiaryEntityData:collectionIntemidiaryEntity ) {
			if(collectionIntemidiaryEntityData.getAction().equalsIgnoreCase("verify")&& collectionIntemidiaryEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				CollectionIntemidiaryPage collectionIntemidiaryPage=new CollectionIntemidiaryPage(driver, "Collection");
					 collectionIntemidiaryPage.fillAndSubmitCollectionPageDetails((CollectionIntemidiaryEntity)collectionIntemidiaryEntityData, assertReference, stepGroup);
			}

		}
	}





	public void setEditQuoteNoDependency(GenericEntity userData, TestData testData) {
		if (userData.getStringValueForField("DependencyForQuoteNo") != null) {
			List<? extends GenericEntity> summaryPageEntityList = testData.getObjectByReference(testData.getData().get(SummaryPageEntity.class),userData.getStringValueForField("DependencyForQuoteNo"));
			for (GenericEntity summaryPageEntityListData : summaryPageEntityList) {
				summaryPageEntityListData.setStringValueForField("QuoteNo",userData.getStringValueForField("QuoteNumber"));
				testData.updateRecordsForCriteria(summaryPageEntityListData);
			}
		}
	}
	//
	public void CreateInsuredDetailsPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> tWInsuredDetailsIntmyEntity=testData.getData().get(TWInsuredDetailsIntmyEntity.class);
		for(GenericEntity tWInsuredDetailsIntmyEntityData:tWInsuredDetailsIntmyEntity){
			if(tWInsuredDetailsIntmyEntityData.getAction().equalsIgnoreCase("add") && tWInsuredDetailsIntmyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				TWInsuredDetailsIntmyPage tWInsuredDetailsIntmyPage = new TWInsuredDetailsIntmyPage(driver, "Insured Details");
				tWInsuredDetailsIntmyPage.fillandSubmitTWInsuredDetails((TWInsuredDetailsIntmyEntity)tWInsuredDetailsIntmyEntityData, assertReference,stepGroup);	
			}
		}
	}
	public void EditInsuredDetailsPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> tWInsuredDetailsIntmyEntity=testData.getData().get(TWInsuredDetailsIntmyEntity.class);
		for(GenericEntity tWInsuredDetailsIntmyEntityData:tWInsuredDetailsIntmyEntity){
			if(tWInsuredDetailsIntmyEntityData.getAction().equalsIgnoreCase("edit") && tWInsuredDetailsIntmyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				TWInsuredDetailsIntmyPage tWInsuredDetailsIntmyPage = new TWInsuredDetailsIntmyPage(driver, " Insured Details");
				tWInsuredDetailsIntmyPage.fillandSubmitTWInsuredDetails((TWInsuredDetailsIntmyEntity)tWInsuredDetailsIntmyEntityData, assertReference,stepGroup);	
			}
		}
	}
	public void VerifyInsuredDetailsPage(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> tWInsuredDetailsIntmyEntity=testData.getData().get(TWInsuredDetailsIntmyEntity.class);
		for(GenericEntity tWInsuredDetailsIntmyEntityData:tWInsuredDetailsIntmyEntity){
			if(tWInsuredDetailsIntmyEntityData.getAction().equalsIgnoreCase("verify") && tWInsuredDetailsIntmyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				TWInsuredDetailsIntmyPage tWInsuredDetailsIntmyPage = new TWInsuredDetailsIntmyPage(driver, " Insured Details");
				tWInsuredDetailsIntmyPage.fillandSubmitTWInsuredDetails((TWInsuredDetailsIntmyEntity)tWInsuredDetailsIntmyEntityData, assertReference,stepGroup);	
			}
		}
	}
	//

	public void CreateTWBasicPremiumIntmy(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> TWBasicPremiumIntmyEntity=testData.getData().get(TWBasicPremiumIntmyEntity.class);
		for(GenericEntity TWBasicPremiumIntmyEntityData:TWBasicPremiumIntmyEntity){
			if(TWBasicPremiumIntmyEntityData.getAction().equalsIgnoreCase("add") && TWBasicPremiumIntmyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				TWBasicPremiumIntmdyPage TWBasicPremiumIntmdyPage = new TWBasicPremiumIntmdyPage(driver, "Basic Premium");
				TWBasicPremiumIntmdyPage.fillAndSubmitTWBasicPremiumPageDetails((TWBasicPremiumIntmyEntity)TWBasicPremiumIntmyEntityData, assertReference,stepGroup);	
			}
		}
	}
	public void EditTWBasicPremiumIntmy(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> TWBasicPremiumIntmyEntity=testData.getData().get(TWBasicPremiumIntmyEntity.class);
		for(GenericEntity TWBasicPremiumIntmyEntityData:TWBasicPremiumIntmyEntity){
			if(TWBasicPremiumIntmyEntityData.getAction().equalsIgnoreCase("edit") && TWBasicPremiumIntmyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				TWBasicPremiumIntmdyPage TWBasicPremiumIntmdyPage = new TWBasicPremiumIntmdyPage(driver, "Basic Premium");
				TWBasicPremiumIntmdyPage.fillAndSubmitTWBasicPremiumPageDetails((TWBasicPremiumIntmyEntity)TWBasicPremiumIntmyEntityData, assertReference,stepGroup);	
			}
		}
	}
	public void VerifyTWBasicPremiumIntmy(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> TWBasicPremiumIntmyEntity=testData.getData().get(TWBasicPremiumIntmyEntity.class);
		for(GenericEntity TWBasicPremiumIntmyEntityData:TWBasicPremiumIntmyEntity){
			if(TWBasicPremiumIntmyEntityData.getAction().equalsIgnoreCase("verify") && TWBasicPremiumIntmyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				TWBasicPremiumIntmdyPage TWBasicPremiumIntmdyPage = new TWBasicPremiumIntmdyPage(driver, "Basic Premium");
				TWBasicPremiumIntmdyPage.fillAndSubmitTWBasicPremiumPageDetails((TWBasicPremiumIntmyEntity)TWBasicPremiumIntmyEntityData, assertReference,stepGroup);	
			}
		}
	}
	//
	public void CreateTWdetailsIntmy(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> TWdetailsIntmyEntity=testData.getData().get(TWdetailsIntmyEntity.class);
		for(GenericEntity TWdetailsIntmyEntityData:TWdetailsIntmyEntity){
			if(TWdetailsIntmyEntityData.getAction().equalsIgnoreCase("add") && TWdetailsIntmyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				TWDetailsIntmdryPage TWDetailsIntmdryPage = new TWDetailsIntmdryPage(driver, "Basic Premium");
				TWDetailsIntmdryPage.fillAndSubmitTwoWheelerIntermidiaryDetails((TWdetailsIntmyEntity)TWdetailsIntmyEntityData, assertReference,stepGroup);	
			}
		}
	}
	public void EditTWdetailsIntmy(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> TWdetailsIntmyEntity=testData.getData().get(TWdetailsIntmyEntity.class);
		for(GenericEntity TWdetailsIntmyEntityData:TWdetailsIntmyEntity){
			if(TWdetailsIntmyEntityData.getAction().equalsIgnoreCase("edit") && TWdetailsIntmyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				TWDetailsIntmdryPage TWDetailsIntmdryPage = new TWDetailsIntmdryPage(driver, "Basic Premium");
				TWDetailsIntmdryPage.fillAndSubmitTwoWheelerIntermidiaryDetails((TWdetailsIntmyEntity)TWdetailsIntmyEntityData, assertReference,stepGroup);	
			}
		}
	}
	public void VerifyTWdetailsIntmy(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> TWdetailsIntmyEntity=testData.getData().get(TWdetailsIntmyEntity.class);
		for(GenericEntity TWdetailsIntmyEntityData:TWdetailsIntmyEntity){
			if(TWdetailsIntmyEntityData.getAction().equalsIgnoreCase("verify") && TWdetailsIntmyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				TWDetailsIntmdryPage TWDetailsIntmdryPage = new TWDetailsIntmdryPage(driver, "Basic Premium");
				TWDetailsIntmdryPage.fillAndSubmitTwoWheelerIntermidiaryDetails((TWdetailsIntmyEntity)TWdetailsIntmyEntityData, assertReference,stepGroup);	
			}
		}
	}
	//
	public void CreateVehicleDetailsIntermidiary(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> VehicleDetailsIntmyEntity=testData.getData().get(VehicleDetailsIntmyEntity.class);
		for(GenericEntity VehicleDetailsIntmyEntityData:VehicleDetailsIntmyEntity){
			if(VehicleDetailsIntmyEntityData.getAction().equalsIgnoreCase("add") && VehicleDetailsIntmyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				VehicleDetailsIntermidiaryPage VehicleDetailsIntermidiaryPage = new VehicleDetailsIntermidiaryPage(driver, "Basic Premium");
				VehicleDetailsIntermidiaryPage.fillAndSubmitVehicleDetailPageDetails((VehicleDetailsIntmyEntity)VehicleDetailsIntmyEntityData, assertReference, stepGroup);

			}
		}
	}
	public void EditVehicleDetailsIntermidiary(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> VehicleDetailsIntmyEntity=testData.getData().get(VehicleDetailsIntmyEntity.class);
		for(GenericEntity VehicleDetailsIntmyEntityData:VehicleDetailsIntmyEntity){
			if(VehicleDetailsIntmyEntityData.getAction().equalsIgnoreCase("edit") && VehicleDetailsIntmyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				VehicleDetailsIntermidiaryPage VehicleDetailsIntermidiaryPage = new VehicleDetailsIntermidiaryPage(driver, "Basic Premium");
				VehicleDetailsIntermidiaryPage.fillAndSubmitVehicleDetailPageDetails((VehicleDetailsIntmyEntity)VehicleDetailsIntmyEntityData, assertReference, stepGroup);

			}
		}
	}
	public void VerifyVehicleDetailsIntermidiary(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> VehicleDetailsIntmyEntity=testData.getData().get(VehicleDetailsIntmyEntity.class);
		for(GenericEntity VehicleDetailsIntmyEntityData:VehicleDetailsIntmyEntity){
			if(VehicleDetailsIntmyEntityData.getAction().equalsIgnoreCase("verify") && VehicleDetailsIntmyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				VehicleDetailsIntermidiaryPage VehicleDetailsIntermidiaryPage = new VehicleDetailsIntermidiaryPage(driver, "Basic Premium");
				VehicleDetailsIntermidiaryPage.fillAndSubmitVehicleDetailPageDetails((VehicleDetailsIntmyEntity)VehicleDetailsIntmyEntityData, assertReference, stepGroup);

			}
		}
	}
	//
	public void createQuickRenewPolicy(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> QuickRenewPolicyEntity=testData.getData().get(QuickRenewPolicyEntity.class);
		for(GenericEntity QuickRenewPolicyEntityData:QuickRenewPolicyEntity){
			if(QuickRenewPolicyEntityData.getAction().equalsIgnoreCase("add") && QuickRenewPolicyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				QuickPayRenewalPolicyDetailsPage quickPayRenewalPolicyDetailsPage = new QuickPayRenewalPolicyDetailsPage(driver, "Basic Premium");
				quickPayRenewalPolicyDetailsPage.fillAndSubmitQuickPayRenewalPolicyDetails((QuickRenewPolicyEntity)QuickRenewPolicyEntityData, assertReference, stepGroup);

			}
		}
	}
	public void editQuickRenewPolicy(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> QuickRenewPolicyEntity=testData.getData().get(QuickRenewPolicyEntity.class);
		for(GenericEntity QuickRenewPolicyEntityData:QuickRenewPolicyEntity){
			if(QuickRenewPolicyEntityData.getAction().equalsIgnoreCase("edit") && QuickRenewPolicyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				QuickPayRenewalPolicyDetailsPage quickPayRenewalPolicyDetailsPage = new QuickPayRenewalPolicyDetailsPage(driver, "Basic Premium");
				quickPayRenewalPolicyDetailsPage.fillAndSubmitQuickPayRenewalPolicyDetails((QuickRenewPolicyEntity)QuickRenewPolicyEntityData, assertReference, stepGroup);

			}
		}
	}
	public void verifyQuickRenewPolicy(TestData testData,ExecutionTestSteps executionTestStep,CustomAssert assertReference,AppiumDriver driver,String stepGroup) throws InterruptedException{
		List<? extends GenericEntity> QuickRenewPolicyEntity=testData.getData().get(QuickRenewPolicyEntity.class);
		for(GenericEntity QuickRenewPolicyEntityData:QuickRenewPolicyEntity){
			if(QuickRenewPolicyEntityData.getAction().equalsIgnoreCase("verify") && QuickRenewPolicyEntityData.getStepGroup().equalsIgnoreCase(stepGroup)){
				QuickPayRenewalPolicyDetailsPage quickPayRenewalPolicyDetailsPage = new QuickPayRenewalPolicyDetailsPage(driver, "Basic Premium");
				quickPayRenewalPolicyDetailsPage.fillAndSubmitQuickPayRenewalPolicyDetails((QuickRenewPolicyEntity)QuickRenewPolicyEntityData, assertReference, stepGroup);

			}
		}
	}

}	

/*if(partyEntity.getStringValueForField("DependencyForSuperUserUserCode")!=null){
			ArrayList<SecurityPartyEntity> securityPartyEntityList=testData.getObjectByReference(testData.getData().get(SecurityPartyEntity.class), partyEntity.getStringValueForField("DependencyForSuperUserUserCode"));

			for(SecurityPartyEntity securityPartyEntityListData:securityPartyEntityList){
				securityPartyEntityListData.setStringValueForField("UserCode",partyEntity.getStringValueForField("PartyCode"));
				testData.updateRecordsForCriteria(securityPartyEntityListData);
			}
		}


	}
 */



