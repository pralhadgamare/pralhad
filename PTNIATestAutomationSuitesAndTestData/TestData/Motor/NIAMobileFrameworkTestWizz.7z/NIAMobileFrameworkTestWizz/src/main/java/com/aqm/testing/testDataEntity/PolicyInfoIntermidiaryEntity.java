package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class PolicyInfoIntermidiaryEntity extends GenericEntity{

	public PolicyInfoIntermidiaryEntity() {
		super("PolicyInfoIntermidiaryEntity");
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	

}
