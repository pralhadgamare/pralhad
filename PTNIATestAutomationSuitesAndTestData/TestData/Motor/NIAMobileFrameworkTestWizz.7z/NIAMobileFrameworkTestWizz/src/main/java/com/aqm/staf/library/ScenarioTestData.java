package com.aqm.staf.library;

import org.hibernate.Session;

import com.aqm.framework.core.TestData;
import com.aqm.testing.testDataEntity.*;

public class ScenarioTestData extends TestData{

	public ScenarioTestData(Session sessionTestData) {
		super(sessionTestData);
	}
	
	@Override
	public void scenarioDataInfo(String testScenarioReference)
	{
		setScenarioData(BuyandSellEntity.class, testScenarioReference);
		setScenarioData(AdditionalDetailsMotorEntity.class, testScenarioReference);
		setScenarioData(AdditionalDetailsPageForIntermidiaryEntity.class, testScenarioReference);
		setScenarioData(AddressFinancierDetailEntity.class, testScenarioReference);
		setScenarioData(AdtionalDetalsInterEntity.class, testScenarioReference);
		setScenarioData(BuyandSellEntity.class, testScenarioReference);
		setScenarioData(BuyNowEntermidiaryEntity.class, testScenarioReference);
		setScenarioData(BuyNowEntity.class, testScenarioReference);
		setScenarioData(BuyNowInterEntity.class, testScenarioReference);
		setScenarioData(CollectionIntemidiaryEntity.class, testScenarioReference);
		setScenarioData(DetailedTravelEntity.class, testScenarioReference);
		setScenarioData(HealthAddDetailEntity.class, testScenarioReference);
		setScenarioData(HomeIntermediaryEntity.class, testScenarioReference);
		setScenarioData(HomepageEntity.class, testScenarioReference);
		setScenarioData(Home_IntermediaryEntity.class, testScenarioReference);
		setScenarioData(LoginEntity.class, testScenarioReference);
		setScenarioData(PersonalAccidentDetEntity.class, testScenarioReference);
		setScenarioData(PolicyHolderInformationIntermidiaryEntity.class, testScenarioReference);
		setScenarioData(PolicyInfoIntermidiaryEntity.class, testScenarioReference);
		setScenarioData(PremiumCalculateEntity.class, testScenarioReference);
		setScenarioData(PremiumCalEntity.class, testScenarioReference);
		setScenarioData(PremiumSummaryEntity.class, testScenarioReference);
		setScenarioData(PrivateCarEntity.class, testScenarioReference);
		setScenarioData(QuickRenewPolicyEntity.class, testScenarioReference);
		setScenarioData(RecentActivitiesEntity.class, testScenarioReference);
		setScenarioData(SummaryIntermidiarEntity.class, testScenarioReference);
		setScenarioData(SummaryPageEntity.class, testScenarioReference);
		setScenarioData(TopUpMediEntity.class, testScenarioReference);
		setScenarioData(TWBasicPremiumIntmyEntity.class, testScenarioReference);
		setScenarioData(TWdetailsIntmyEntity.class, testScenarioReference);
		setScenarioData(TWInsuredDetailsIntmyEntity.class, testScenarioReference);
		setScenarioData(TwoWheelerBasicPremiumEntity.class, testScenarioReference);
		setScenarioData(TwoWheelerBuyInsuranceEntity.class, testScenarioReference);
		setScenarioData(TwoWheelerDetailsEntity.class, testScenarioReference);
		setScenarioData(VehicleDetailsIntmyEntity.class, testScenarioReference);
	}
}