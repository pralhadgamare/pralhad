package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class BuyNowInterEntity extends GenericEntity {

	public BuyNowInterEntity() {
		super("BuyNowInterEntity");
		// TODO Auto-generated constructor stub
	}

}
