package com.aqm.staf.library.pages.common;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import com.aqm.framework.constant.WaitType;
import com.aqm.framework.core.MobileScreen;
import com.aqm.framework.core.MobileScreenElement;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class PersonalAccidentAdditional extends MobileScreen {

	MobileScreenElement relationshipWithRegisteredUser;

	public PersonalAccidentAdditional(AppiumDriver driver, String screenName)
	{
		super((AndroidDriver) driver,screenName);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		relationshipWithRegisteredUser = new MobileScreenElement(By.xpath("//android.widget.Button[@content-desc='Select']"), "Relationship With Registered User", false, WaitType.WAITFORELEMENTTOBEEENABLED, 10);

	}
}

