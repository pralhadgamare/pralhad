package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class TwoWheelerDetailsEntity extends GenericEntity {

	public TwoWheelerDetailsEntity() {
		super("TwoWheelerDetailsEntity");
		// TODO Auto-generated constructor stub
	}

}
