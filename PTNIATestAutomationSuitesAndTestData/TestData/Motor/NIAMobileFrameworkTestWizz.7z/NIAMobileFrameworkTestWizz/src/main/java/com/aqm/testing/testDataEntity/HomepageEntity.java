package com.aqm.testing.testDataEntity;
import com.aqm.framework.core.GenericEntity;

public class HomepageEntity extends GenericEntity{

	public HomepageEntity() {
		super("HomepageEntity");
		// TODO Auto-generated constructor stub
	}

}
